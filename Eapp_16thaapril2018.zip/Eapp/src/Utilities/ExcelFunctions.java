/**
 * 
 */
package Utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.CellReference;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;

/**
 * Class to Read data and write data into Excel File
 * @author 
 *
 */
public class ExcelFunctions {
	
		/**
		 * Method to Read Excel Data
		 * @param sheetName-  Excel sheet name
		 * @param filePath - Location of excel file
		 * @param rowData -  Data in the Particular Row
		 * @param colData  - Column Name
		 * @return   - This function will return String value 
		 * @throws IOException
		 */
	public String getExcelData(String sheetName, String filePath,
		String rowData, String colData) throws IOException {
		String output = null;
		try {

			File fileName = new File(filePath);
			// File fileName = new File(filePath);
			InputStream inp = new FileInputStream(fileName);

			HSSFWorkbook workbook = new HSSFWorkbook(inp);
			HSSFSheet sheet = workbook.getSheet(sheetName);



			FormulaEvaluator formulaEvaluator = workbook.getCreationHelper()
				.createFormulaEvaluator();
			// Get the row index on the sheet.
			int rowind = findRow(sheet, rowData);
			System.out.println("rowindex" + rowind);
			if(rowind>=0)
			{
			String ref = null;

			// Get the column index on the sheet.
			DataFormatter fmt = new DataFormatter();
			for (Row r : sheet) {
				for (Cell c : r) {  //c- reads each columnname(header) from excelsheet
					if (colData.equals(fmt.formatCellValue(c))) {
						// Found it!
						int columnIndex = c.getColumnIndex();
						ref = ((new CellReference(rowind, columnIndex))
							.formatAsString());
						break;

					}
				}
			}

			// Return Value
			CellReference cellRef = null;
			try {
				cellRef = new CellReference(ref);
			} catch (Exception e) {
				System.out
					.println("Following feild  may not be in excel sheet : "
						+ rowData + "Or  :" + colData);
				e.printStackTrace();
			}

			Row r = sheet.getRow(cellRef.getRow());
			if (r != null) {
				Cell c = r.getCell(cellRef.getCol());
				// output= c.toString();

				// To handle num string 
				if (c == null) {
					output = null;
				} else {

					DataFormatter dataFormatter = new DataFormatter();
					output = dataFormatter
						.formatCellValue(formulaEvaluator.evaluateInCell(c));
					//System.out.println(output);
				}

			}
			workbook.close(); // close the work book
			}
		} catch (Exception ex) {
			if (ex instanceof NullPointerException) {
				try {
					throw ex;
				} catch (Exception e) {
					
					e.printStackTrace();                                              
				}
				
			}
		}
		
		return output;

	}

	//Row index based on input string
	private static int findRow(Sheet sheet, String cellContent)
	{ 
		int rowNum = 0; 
		for (Row row : sheet) {
			for (Cell cell : row) {	
				 
				//System.out.println("rowindex" + sheet +cellContent+row.getRowNum()+cell.getColumnIndex());
				//System.out.println(cell.getRichStringCellValue().getString().trim());
				if (cell.getRichStringCellValue().getString().trim().equals(cellContent)) {
					rowNum = row.getRowNum();
					//System.out.println("hi" +row);
					 return row.getRowNum();   
				}
			}
		} 
		//System.out.println("Exit");.....
		return 0;
	}
	
	/**
	 * This Method will return the Last Row number of a Excel Sheet
	 * @param filePath
	 * @param sheetName
	 * @return
	 */
	public  int Last_Row(String filePath, String sheetName) {
			
		try {
			int rowNum = 0;
			File fileName = new File(filePath);   
			InputStream inp = new FileInputStream(fileName);

			HSSFWorkbook workbook = new HSSFWorkbook(inp);
			Sheet sheet2 = workbook.getSheet(sheetName);
			rowNum = sheet2.getLastRowNum();
			return rowNum;
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
		return 0;
	}
	
	
	
	/**
	 * This Method will write the data in to Excel File
	 * @param testSuite - to  select Excel file name & Sheet Name as per project
	 * @param index
	 * @param colName
	 * @param Result
	 * @return
	 */
	
	public boolean writeResult( String testSuite, String index,String colName, String Result ){
		try{
			String filelocation = null;
			String wsName = null;
			if(testSuite == "Result"){
			filelocation ="resources/STPData.xls";
			wsName = "Comparing_Result";
			}else if (testSuite == "TestData"){
				filelocation ="resources/STPData.xls";
				wsName = "TestData";
			}
			InputStream inp = new FileInputStream(filelocation);
			HSSFWorkbook wb = new HSSFWorkbook(inp);
			
						
			Sheet sheet = wb.getSheet(wsName);
			
			int sheetIndex=wb.getSheetIndex(wsName);
			if(sheetIndex==-1)
				return false;			
			int colNum = retrieveNoOfCols(wb,wsName);
			int colNumber=-1;
			//System.out.println(colNum);
					
			
			HSSFRow Suiterow = ws.getRow(0);			
			for(int i=0; i<colNum; i++){				
				if(Suiterow.getCell(i).getStringCellValue().equals(colName.trim())){
					colNumber=i;					
				}					
			}
			
			if(colNumber==-1){
				return false;				
			}
			
			HSSFRow Row = ws.getRow(findRow(sheet, index) );
			HSSFCell cell = Row.getCell(colNumber);
			if (cell == null)
		        cell = Row.createCell(colNumber);			
			
			cell.setCellValue(Result);
			
			FileOutputStream opstr = new FileOutputStream(filelocation);
			wb.write(opstr);
			opstr.close();
			
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
		return true;
	}
	private HSSFSheet ws = null;
	
	//To retrieve No Of Columns from .cls file's sheets.
		public int retrieveNoOfCols(HSSFWorkbook wb,String wsName){
			int sheetIndex=wb.getSheetIndex(wsName);
			if(sheetIndex==-1)
				return 0;
			else{
				ws = wb.getSheetAt(sheetIndex);
				int colCount=ws.getRow(0).getLastCellNum();			
				return colCount;
			}
		}
		
		
		public void Write_excel_Data(String filePath , String sheetName, String rowName, String coloumName,String Data )
		{
			try {
				
				String ref = null;
				File fileName = new File(filePath);    	
				//File fileName = new File(filePath);
				InputStream inp = new FileInputStream(fileName);

				HSSFWorkbook workbook = new HSSFWorkbook(inp);
				Sheet sheet = workbook.getSheet(sheetName);
				int rowind = findRow(sheet,rowName);
				
				
				
				
				String ref2 = null;
				
				//Get the column index on the sheet.		
				DataFormatter fmt = new DataFormatter();
				for (Row r : sheet) {
					for (Cell c : r) {
						if (coloumName.equals(fmt.formatCellValue(c))) {
							// Found it!
							int columnIndex = c.getColumnIndex();                      
							// Get the Excel style reference, eg C12
							ref2 = ((new CellReference(rowind,columnIndex)).formatAsString());
							System.out.println(ref2);
							
						}
					}
				}

				//Return Value
				CellReference cellRef = new CellReference(ref2);

				Row r = sheet.getRow(cellRef.getRow());
				//if (r != null) {
					Cell c = r.getCell(cellRef.getCol());
					c.setCellValue(Data);
					
					FileOutputStream opstr = new FileOutputStream(filePath);
					workbook.write(opstr);
					opstr.close();
					workbook.close();
					
				//}
				
			/*	DataFormatter fmt = new DataFormatter();
				for (Row r : sheet) {
					for (Cell c : r) {
						if (coloumName.equals(fmt.formatCellValue(c))) {
							int columnIndex = c.getColumnIndex();  
							
							Cell cell = r.getCell(columnIndex);
							if (cell == null)
						        cell = Row.createCell(columnIndex);			
							
							cell.setCellValue(Result);
							
							FileOutputStream opstr = new FileOutputStream(filelocation);
							wb.write(opstr);
							opstr.close();
							*/
							
							
							/*// Found it!
							int columnIndex = c.getColumnIndex();                      
							// Get the Excel style reference, eg C12
							 ref = ((new CellReference(rowind,columnIndex)).formatAsString());
							
							//Return Value
							CellReference cellRef = new CellReference(ref);

							Row r2 = sheet.getRow(cellRef.getRow());
									
							int colNum = retrieveNoOfCols(workbook,sheetName);
							int colNumber=-1;
							System.out.println(colNum);
									
							
							
							HSSFRow Row = ws.getRow(findRow(sheet, index) );
							HSSFCell cell = Row.getCell(colNumber);
							if (cell == null)
						        cell = Row.createCell(colNumber);	
							
							*/
							

			} catch (FileNotFoundException e) {
				
				e.printStackTrace();
			} catch (IOException e) {
				
				e.printStackTrace();
			}
		}
		
		
		
		
		public boolean writeResult_UsingIndex( String testSuite, int Row_Number,int ColoumNumber, String Result ){
			try{
				String filelocation = null;
				String wsName = null;
				if(testSuite == "Result"){
				filelocation ="resources/Regression_TestResult.xls";//resources/LSPData.xls
				wsName = "Comparing_Result";
				}
				else if(testSuite == "InputData"){
					filelocation ="resources/LSPData.xls";
					wsName = "InputData";
				}else if (testSuite == "Test Result"){
					filelocation ="resources/Regression_TestResult.xls";
					wsName = "Regression_TestResults";
				}
				InputStream inp = new FileInputStream(filelocation);
				HSSFWorkbook wb = new HSSFWorkbook(inp);
				
							
				Sheet sheet = wb.getSheet(wsName);
				
				int sheetIndex=wb.getSheetIndex(wsName);
				if(sheetIndex==-1)
					return false;			
				Row Row = sheet.getRow(Row_Number );		
				
				if(Row== null)
				{
					 Row = sheet.createRow(Row_Number);
					 Row = sheet.getRow(Row_Number );	
				}
				Cell cell = Row.getCell(ColoumNumber);
				
				if(cell== null)
				{
					cell = Row.createCell(ColoumNumber);
					cell = Row.getCell(ColoumNumber);
				}
						
				
				cell.setCellValue(Result);
				
				FileOutputStream opstr = new FileOutputStream(filelocation);
				wb.write(opstr);
				opstr.close();
				wb.close();
				
				
			}catch(Exception e){
				e.printStackTrace();
				
				return false;
			}
			return true;
		}
		
		


}
