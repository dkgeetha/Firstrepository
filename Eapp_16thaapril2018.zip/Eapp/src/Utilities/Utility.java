package Utilities;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;


/**
 * Class contains Utility Functions
 * @author ha0127
 *
 */

public class Utility {
	/**
	 * Method to Take screen shot 
	 * @param driver - web Driver
	 * @param screenshotName - file name
	 */
	public static  void captureScreenshot(WebDriver driver,String screenshotName){	 
		try{
			TakesScreenshot ts=(TakesScreenshot)driver;	 
			File source=ts.getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(source, new File("./Screenshots/"+screenshotName+".png"));	 
			System.out.println("Screenshot taken");
		} 
		catch (Exception e)
		{	 
			System.out.println("Exception while taking screenshot "+e.getMessage());
		}
	}
	
	
	
	/**
	 * Function to get the separator string to be used for directories and files based on the current OS
	 * @return The file separator string
	 */
	public  String getFileSeparator()
	{
		return System.getProperty("file.separator");
	}
	
	
	public static Date getCurrentTime()
	{
		Calendar calendar = Calendar.getInstance();
		return calendar.getTime();
	}
	
	/**
	 * Function to return the current time, formatted as per the DateFormatString setting
	 * @param dateFormatString The date format string to be applied
	 * @return The current time, formatted as per the date format string specified
	 * @see #getCurrentTime()
	 * @see #getFormattedTime(Date, String)
	 */
	public  String getCurrentFormattedTime(String dateFormatString)
	{
		DateFormat dateFormat = new SimpleDateFormat(dateFormatString);
		Calendar calendar = Calendar.getInstance();
		return dateFormat.format(calendar.getTime());
	}
	
	/**
	 * Function to format the given time variable as specified by the DateFormatString setting
	 * @param time The date/time variable to be formatted
	 * @param dateFormatString The date format string to be applied
	 * @return The specified date/time, formatted as per the date format string specified
	 * @see #getCurrentFormattedTime(String)
	 */
	public static String getFormattedTime(Date time, String dateFormatString)
	{
		DateFormat dateFormat = new SimpleDateFormat(dateFormatString);
		return dateFormat.format(time);
	}
	
	/**
	 * Function to get the time difference between 2 Date variables in minutes/seconds format
	 * @param startTime The start time
	 * @param endTime The end time
	 * @return Time difference in minutes/seconds format
	 */
	public static String getTimeDifference(Date startTime, Date endTime)
	{
		long timeDifference = endTime.getTime() - startTime.getTime();
		timeDifference /= 1000;	// to convert from milliseconds to seconds
		String timeDifferenceDetailed = Long.toString(timeDifference / 60) + " minute(s), "
										+ Long.toString(timeDifference % 60) + " seconds";
		return timeDifferenceDetailed;
	}
	
	public  void takeScreenshot(WebDriver driver,String screenshotName){	 
		try{
			TakesScreenshot ts=(TakesScreenshot)driver;	 
			File source=ts.getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(source, new File("./Screenshots/Custom_Screenshots/"+screenshotName+".png"));	 
			System.out.println("Screenshot taken");
		} 
		catch (Exception e)
		{	 
			System.out.println("Exception while taking screenshot "+e.getMessage());
		}
	}
	
}
