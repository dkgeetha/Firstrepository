package STP_CustomReport;

import java.util.HashMap;
import java.util.Map;
/**
 * Class Contains Test case Descriptions
 * @author 
 *
 */
public class TestCase_Description {
	public static Map<String, String> testcaseDesc = new HashMap<String, String>();
	
	public static final  String testcase = null;

}
