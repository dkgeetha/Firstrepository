/**
 * @author ha0127
 */
package eApp.Case;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import javax.management.DescriptorKey;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
//import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerDriverService;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import HTML_Report.Report;
import HTML_Report.Status;
import Utilities.ExcelFunctions;
import Utilities.Utility;
import Utilities.WebDriverUtil;

public class EappMainFunction {

	public WebDriver driver;
	public WebDriverUtil objWait;
	EAppCaseCreation newCase = new EAppCaseCreation();
	STP_XmlComparison xmlvalidation = new STP_XmlComparison();
	ExcelFunctions readData = new ExcelFunctions();
	ExcelData xlData = new ExcelData();
	Report report = new Report();
	static Set windows;
	String testMethod;
	String testCaseName, runStatus, User;
	int testCaseNum=1;
	String str;

	EappMainFunction() 
	{
		this.objWait = new WebDriverUtil(driver);
	}

	@BeforeMethod
	public void STPExecution() {
		
		try 
		{
			Load_Config();
			Open_Browser();
		}

		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	public void Open_Browser() {
		try 
		{
			switch (str)
			{

			case "Chrome":
				System.out.println("Invoking Chrome Browser...!");
				browser("Chrome");
				break;
			case "IE":
				System.out.println("Invoking IE Browser");
				browser("IE");
				break;
			case "Firefox":
				System.out.println("Invoking Firefox Browser");
				browser("Firefox");
				break;
			default:
				System.out.println("Default");
			}
		} 
		catch (Exception e) 
		{
			System.out.println("Error while Invoking Browser" + e.getMessage());
			e.printStackTrace();
			Reporter.log(e.getMessage());
		}
	}
	
	public void Load_Config() 
	{
		File configFile = new File("Config.properties");
		try 
		{
			FileReader reader = new FileReader(configFile);
		    Properties props = new Properties();
		    props.load(reader);

		    str = props.getProperty("str");
		    reader.close();
			
		} 
		catch (IOException e1) 
		{
			
			e1.printStackTrace();
		}
	}

	@SuppressWarnings("deprecation")
	public void browser(String browsertype) {
		if (browsertype.equals("Chrome")) {

			System.out.println("Invoking Chrome Browser...!");
			// String projectPath = System.getProperty("user.dir");
			// System.out.println("Current Project path is : " + projectPath);

			String chromePath = "C:\\Temp\\Workspace\\Eapp\\resources\\chromedriver_win32\\chromedriver.exe";
			System.setProperty("webdriver.chrome.driver", chromePath);

			ChromeOptions options = new ChromeOptions(); // Class to manage
															// options specific
															// to ChromeDriver.

			Map<String, Object> prefs = new HashMap<String, Object>();
			prefs.put("credentials_enable_service", false);
			prefs.put("profile.password_manager_enabled", false);

			options.setExperimentalOption("prefs", prefs);
			options.addArguments("chrome.switches", "--disable-extensions");
			// To Disable any browser notifications
			options.addArguments("--disable-notifications");
			// To disable yellow strip info bar which prompts info messages
			options.addArguments("enable-automation");

			driver = new ChromeDriver(options);

			driver.manage().window().maximize();
			this.objWait = new WebDriverUtil(driver);
			objWait.waitFor(3);
		}
		if (browsertype.equals("IE"))
		{
			// IE browser:
			System.out.println("Invoking IE Browser");
			String iePath = "C:\\Temp\\Workspace\\Eapp\\resources\\chromedriver_win32\\IEDriverServer.exe";
			System.setProperty("webdriver.ie.driver", iePath);
			// C:\Temp\Workspace\Eapp\resources\chromedriver_win32
			// DesiredCapabilities capabilities =
			// DesiredCapabilities.internetExplorer();
			// capabilities.setCapability(InternetExplorerDriver.NATIVE_EVENTS,
			// false);
			// driver = new InternetExplorerDriver(capabilities);
			DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
			capabilities.setCapability(InternetExplorerDriver.NATIVE_EVENTS, false);
			capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
			capabilities.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
			capabilities.setCapability("allow-blocked-content", true);
			capabilities.setCapability("allowBlockedContent", true);
			
			driver = new InternetExplorerDriver(capabilities);
			driver.manage().window().maximize();
			this.objWait = new WebDriverUtil(driver);
			objWait.waitFor(3);
		}
		if(browsertype.equals("Firefox"))
		{
			String geckopath= "C:\\Temp\\Workspace\\Eapp\\resources\\chromedriver_win32\\geckodriver.exe";
	
			/*DesiredCapabilities desired = DesiredCapabilities.firefox();
			desired.setCapability("browserName", "firefox");
			desired.setCapability("browserVersion", "59.0.2");
			desired.setCapability("platformName", "Windows");           
			desired.setCapability(CapabilityType.ForSeleniumServer.ENSURING_CLEAN_SESSION, true);*/
			System.setProperty("webdriver.gecko.driver",geckopath);
			
				/*DesiredCapabilities caps=DesiredCapabilities.firefox();
				FirefoxProfile profile = new FirefoxProfile();
				caps.setCapability(FirefoxDriver.PROFILE, profile);
				driver =  new FirefoxDriver(caps);*/
			driver=new FirefoxDriver();
			//driver.navigate().to("https://www.google.com/");
			//driver.findElement(By.xpath("//*[@id='lst-ib']")).sendKeys("gh");

			
		//driver=new FirefoxDriver();
			objWait.waitFor(3);
		}

	}

	public void eAppBrowserLogin() {
		try {
			User = readData.getExcelData(UiMap.RunMangersheet, UiMap.STP_RunMangerPath, testCaseName, "UserToValidate");
			if (User != null) {
				xlData.readLoginCredentials(User);
				driver.get(ExcelData.URL);
				driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
				objWait.waitFor(5);
				//objWait.waitUntilElementVisible(By.cssSelector(UiMap.Wbtxt_UserID), 500);
				//objWait.waitUntilElementVisible(By.xpath(UiMap.Wbtxt_UserIDXpath), 500);
			//	driver.findElement(By.cssSelector(UiMap.Wbtxt_UserID)).sendKeys(ExcelData.UserName);
				driver.findElement(By.xpath(UiMap.Wbtxt_UserIDXpath)).sendKeys(ExcelData.UserName);

				//driver.findElement(By.csssSelector(UiMap.Wbtxt_Password)).sendKeys(ExcelData.Password);
				driver.findElement(By.xpath(UiMap.Wbtxt_PasswordXpath)).sendKeys(ExcelData.Password);
				//driver.findElement(By.cssSelector(UiMap.WbBtn_Login)).click();
				driver.findElement(By.xpath(UiMap.WbBtn_Login_Xpath)).click();
			} else {
				System.out.println("Invalid Data");
			}
		} catch (Exception e) {
			System.out.println("Error in Open URL function  " + e.getMessage());
			e.printStackTrace();
			Reporter.log(e.getMessage());
		}
	}

	public String nationalLifeLogin() throws IOException {
		User = readData.getExcelData(UiMap.RunMangersheet, UiMap.STP_RunMangerPath, testCaseName, "UserToValidate");
		if (User != null) {
			xlData.readLoginCredentials(User);
			driver.get(ExcelData.URL);
			driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
			// objWait.waitFor(5);
			objWait.waitUntilElementVisible(By.cssSelector(UiMap.uatUsername), 300);
			driver.findElement(By.cssSelector(UiMap.uatUsername)).sendKeys(ExcelData.UserName);
			driver.findElement(By.cssSelector(UiMap.uatPwd)).sendKeys(ExcelData.Password);
			driver.findElement(By.cssSelector(UiMap.loginBtn)).click();
		} else {
			return "User is null";
		}
		return "success";
	}

	public void agencyLogin(String testCaseName) throws Exception {
		xlData.readAgencyCredentials(testCaseName);
		driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
		objWait.waitUntilElementVisible(By.cssSelector(UiMap.loginNational), 300);
		driver.findElement(By.cssSelector(UiMap.loginNational)).click();
		driver.findElement(By.cssSelector(UiMap.pUser)).sendKeys(ExcelData.aUserName);
		driver.findElement(By.cssSelector(UiMap.pPassword)).sendKeys(ExcelData.aPassword);
		driver.findElement(By.cssSelector(UiMap.loginNational)).click();
		objWait.waitUntilElementVisible(By.cssSelector(UiMap.conWebsite), 300);
		driver.findElement(By.cssSelector(UiMap.conWebsite)).click();
		objWait.waitUntilElementVisible(By.cssSelector(UiMap.agencyUserId), 500);
		driver.findElement(By.cssSelector(UiMap.agencyUserId)).clear();
		driver.findElement(By.cssSelector(UiMap.agencyUserId)).sendKeys(ExcelData.aName);
		driver.findElement(By.cssSelector(UiMap.goBtn)).click();
		objWait.waitFor(10);

		if (ExcelData.aName.equals("cthree4")) {
			objWait.waitUntilElementVisible(By.cssSelector(UiMap.titleId), 500);
			driver.findElement(By.xpath(UiMap.igoImage)).click();
		} else {
			objWait.waitUntilElementVisible(By.xpath(UiMap.igoLink), 1000);
			driver.findElement(By.xpath(UiMap.igoLink)).click();
			String subWindowHandler = null;
			Set<String> handles = driver.getWindowHandles();
			Iterator<String> iterator = handles.iterator();
			while (iterator.hasNext()) {
				subWindowHandler = iterator.next();
				driver.switchTo().window(subWindowHandler);
				System.out.println(subWindowHandler);
			}

		}

	}
	public void signOut() {
		System.out.println("signout the agent");
		driver.findElement(By.cssSelector(UiMap.welcomeLink)).click();
		driver.findElement(By.cssSelector(UiMap.signOut)).click();
	}

	@Test(priority = 2, description = "TC_01: FixedUniversalLife product, LSW Foundation product type, CA state")
	// public void CaseCreationForLSWFlexlifeII()
	public void FixedUniversalLife() {
		System.out.println("First TC is running");
		boolean CaseCreated = true;
		try {
			String testCase = Integer.toString(testCaseNum);
			if (testCase.length() == 1) {
				testCase = "0" + testCase;
			}
			testCaseName = "TC_" + testCase;
			// testCaseName = "TC_01";Hardcoded
			runStatus = readData.getExcelData(UiMap.RunMangersheet, UiMap.STP_RunMangerPath, testCaseName, "Execute");
			// i.e.(Smoke, Run Manager.xls,TC_01,"Execute)
			// ExcelFunctions readData = new ExcelFunctions();
			// runStatus= Yes
			testMethod = readData.getExcelData(UiMap.RunMangersheet, UiMap.STP_RunMangerPath, testCaseName,
					"MethodName");// Above,
									// testmethod=CaseCreationForLSWFlexlifeII(i.e.It
									// fetched the method name from excel whose
									// Execute status is YES.

			if (runStatus.equals("Yes")) {
				eAppBrowserLogin(); // Login is done and landed at start new
									// case tab (Main page/First page)
				xlData.readAllDetails(testCaseName);

				// ExcelData xlData = new ExcelData();
				String result = newCase.newCaseCreation(driver, objWait, testCaseName, xlData); // Important
																								// line
				// Above, EAppCaseCreation newCase = new EAppCaseCreation();
				if (result.equals("pass")) {
					report.UpdateResult(testCaseName, ExcelData.Product, "Case Created", Status.PASS, ExcelData.TransId,
							"");
				} else {
					Utility.captureScreenshot(driver, testCaseName + "_" + ExcelData.Product);
					report.UpdateResult(testCaseName, ExcelData.Product, "Error in Case Creation", Status.FAIL,
							EAppCaseCreation.errorMessage, testCaseName + "_" + ExcelData.Product);
				}
			}
			System.out.println("Scenario 1 completed successfully");
		} catch (Exception e) {
			CaseCreated = false;
			Utility.captureScreenshot(driver, testCaseName + "_" + ExcelData.Product);

			report.UpdateResult(testCaseName, testMethod, "Validate Script Error", Status.FAIL,
					EAppCaseCreation.errorMessage, testCaseName + "_" + ExcelData.Product);
			e.printStackTrace();
			System.out.println("Error Message  " + EAppCaseCreation.errorMessage);
		} finally {
			Assert.assertEquals(CaseCreated, true);
		}
	}

	@Test(priority = 3, description = "TC_03:TermInsurance product, LSW Level Term-10G product type, CA state")
	// public void validate5TZAgency() // Rename this method
	public void TermInsurance() {
		System.out.println(" TC_03 is running");
		boolean CaseCreated = true;
		boolean agencyValidation = true;
		try {
			testCaseName = "TC_03";
			runStatus = readData.getExcelData(UiMap.RunMangersheet, UiMap.STP_RunMangerPath, testCaseName, "Execute");
			testMethod = readData.getExcelData(UiMap.RunMangersheet, UiMap.STP_RunMangerPath, testCaseName,
					"MethodName");

			if (runStatus.equals("Yes")) {
				eAppBrowserLogin(); // Login
				xlData.readAllDetails(testCaseName);// Read data from excel(From
													// Test Data sheet)
				xlData.readAgencyCredentials(testCaseName);// Read data from
															// excel from
															// respective
															// sheet(Agency
															// Login sheet)

				String result = newCase.newCaseCreation(driver, objWait, testCaseName, xlData); // Executing
																								// all
																								// methods(pages)
																								// for
																								// case
																								// creation
				if (result.equals("pass")) {
					report.UpdateResult(testCaseName, ExcelData.Product, "Case Created", Status.PASS, ExcelData.TransId,
							"");
				} else {
					Utility.captureScreenshot(driver, testCaseName + "_" + ExcelData.Product);
					report.UpdateResult(testCaseName, ExcelData.Product, "Error in Case Creation", Status.FAIL,
							EAppCaseCreation.errorMessage, testCaseName + "_" + ExcelData.Product);
				}
			}

			System.out.println("Case Creation Scenario is completed successfully for TermInsuracne Prodcut");
		} catch (Exception e) {
			CaseCreated = false;
			Utility.captureScreenshot(driver, testCaseName + "_" + ExcelData.Product);

			report.UpdateResult(testCaseName, testMethod, "Validate Script Error", Status.FAIL,
					EAppCaseCreation.errorMessage, testCaseName + "_" + ExcelData.Product);
			e.printStackTrace();
			System.out.println("Error Message  " + EAppCaseCreation.errorMessage);
		} finally // Finally block gets executed always
		{
			Assert.assertEquals(CaseCreated, true);
		}

	}

	@Test(priority = 1, description = "TC_02: IndexedUniversalLife product, LSW SecurePlus Provider product type, Texas state")
	public void IndexedUniversalLife() {
		boolean CaseCreated = true;
		try {
			int testCaseNum = 2;
			String testCase = Integer.toString(testCaseNum);
			if (testCase.length() == 1) {
				testCase = "0" + testCase;
			}
			testCaseName = "TC_" + testCase;
			// testCaseName = "TC_01";Hardcoded
			runStatus = readData.getExcelData(UiMap.RunMangersheet, UiMap.STP_RunMangerPath, testCaseName, "Execute");
			// i.e.(Smoke, Run Manager.xls,TC_01,"Execute)
			// ExcelFunctions readData = new ExcelFunctions();
			// runStatus= Yes
			testMethod = readData.getExcelData(UiMap.RunMangersheet, UiMap.STP_RunMangerPath, testCaseName,
					"MethodName");// Above,
									// testmethod=CaseCreationForLSWFlexlifeII(i.e.It
									// fetched the method name from excel whose
									// Execute status is YES.

			if (runStatus.equals("Yes")) {
				eAppBrowserLogin(); // Login is done and landed at start new
									// case tab (Main page/First page)
				xlData.readAllDetails(testCaseName);

				// ExcelData xlData = new ExcelData();
				String result = newCase.newCaseCreation(driver, objWait, testCaseName, xlData); // Important
																								// line
				// Above, EAppCaseCreation newCase = new EAppCaseCreation();
				if (result.equals("pass")) {
					report.UpdateResult(testCaseName, ExcelData.Product, "Case Created", Status.PASS, ExcelData.TransId,
							"");
				} else {
					Utility.captureScreenshot(driver, testCaseName + "_" + ExcelData.Product);
					report.UpdateResult(testCaseName, ExcelData.Product, "Error in Case Creation", Status.FAIL,
							EAppCaseCreation.errorMessage, testCaseName + "_" + ExcelData.Product);
				}
			}
			System.out.println("Scenario 1 completed successfully");
		} catch (Exception e) {
			CaseCreated = false;
			Utility.captureScreenshot(driver, testCaseName + "_" + ExcelData.Product);

			report.UpdateResult(testCaseName, testMethod, "Validate Script Error", Status.FAIL,
					EAppCaseCreation.errorMessage, testCaseName + "_" + ExcelData.Product);
			e.printStackTrace();
			System.out.println("Error Message  " + EAppCaseCreation.errorMessage);
		} finally {
			Assert.assertEquals(CaseCreated, true);
		}
	}

	@AfterMethod
	public void closeBrowser() {
		try {
			report.Generate_Report();
			//driver.quit();
			//	driver.close();
			System.out.println("Closing Chrome Driver.........");

		} catch (Exception e) {
			System.out.println("Error Occurred in After Class...");
			System.out.println(e.getMessage());
			e.printStackTrace();
			Reporter.log(e.getMessage());

		}
	}
}
