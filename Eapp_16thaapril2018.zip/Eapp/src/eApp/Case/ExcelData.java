package eApp.Case;

import java.io.IOException;

import Utilities.ExcelFunctions;
/**
 * This Class will public void Read the Data from the Excel File and stores in Variables 
 * @author ha0127
 *
 */

public class ExcelData  {



	public static  ExcelFunctions ReadData = new ExcelFunctions();
	
	//Login Credentials
	public static String TestCaseID 	= null;
	public static String UserName 		= null;
	public static String Password 		= null;
	public static String URL  			= null;
	public static String Name  			= null;
	
	//Agency Credentials
	public static String aUserName 		= null;
	public static String aPassword 		= null;
	public static String aLogin  		= null;
	public static String aName  		= null;

	// Case Information
	public static String InsFirstName 	= null;
	public static String InsLastName 	= null;
	public static String InsDOB 		= null;
	public static String InsGender 		= null;
	public static String Case_Desc		= null;
	public static String Sol_State 		= null;
	public static String Product_Type	= null;
	public static String Product		= null;
	
	//Primary Insured 
	public static String primarySSN = null;
	public static String primaryCountry = null;
	public static String primaryCitizen = null;
	public static String primaryAddress= null;
	public static String primaryCity = null;
	public static String primaryState = null;
	public static String primaryZipcode = null;
	public static String primaryPhoneToContact = null;
	public static String primaryPhoneNum = null;
	public static String primaryMailAddr =null;
	public static String primaryOwner =null;
	public static String primaryJointOwner =null;
	public static String primarySecAdd =null;
	public static String BestNumToCallvalue=null;
	
	//Primary Insured Cont
	public static String priContEmpl = null;
	public static String priContAnnIncome = null;
	public static String priContNet = null;
	public static String priContHouseIncome = null;
	public static String priContNetHouse = null;
	public static String priContreason = null;
	public static String priContNext = null;
	
	//Beneficiaries - Primary Insured
	public static String beneRelation = null;
	public static String beneFirstName = null;
	public static String beneMiddleName = null;
	public static String beneLastName = null;
	public static String beneSSN = null;
	public static String beneDOB = null;
	public static String beneShare = null;
	
	//Coverage Information
	public static String covFaceAmt = null;
	public static String covDeathBO = null;
	
	//Premium Information
	public static String preMode = null;
	public static String prePlanMode = null;
	public static String preSource = null;
	public static String preQuoted = null;
	
	//InterestCredits
	public static String interestFixedTerm = null;
	
	//Physician Info
	public static String physicianType=null;
	public static String physicianFirstName=null;
	public static String physicianLastName=null;
	public static String physicianNumberAndStreet=null;
	public static String physicianCity=null;
	public static String physicianState=null;
	public static String physicianZipCode=null;
	public static String physicianReasonLastConsulted=null;
	public static String physicianDateLastConsulted=null;
	public static String physicianOutcome=null;
	
	
	//Personal Information
	public static String personalHeight = null;
	public static String personalInch = null;
	public static String personalWeight = null;
	public static String PersonalGainOrLossvalue=null;
	public static String PersonalGainOrLossDropDownvalue =null;
	
	//agent Information
	public static String agentKnown = null;
	public static String agentRelated = null;
	public static String agentPurpose = null;
	public static String agentFaceAmtDetermine = null;
	public static String agentAdditionalInfm = null;
	public static String agentRateClass = null;
	public static String agentUnderReq = null;
	public static String agentIDProof = null;
	//public static String agentFirst = null;
	//public static String agentLast = null;
	public static String agencyNumber = null;
	public static String agentNumber = null;
	public static String agentComp = null;
	public static String spAgentName = null;
	public static String spAgentPH = null;
	public static String spAgentNumDD = null;
	public static String spAgentNum = null;
	public static String spAgentComp = null;
	
	//

	//Additional Paperwork	
	public static String TransId		= null;	
	
	public  void  readAllDetails(String TestCaseVal) throws Exception
	{
		TestCaseID = TestCaseVal;//TC_01
		 readCaseInfoDetails();
		 readPrimaryInsured();
		 readPrimaryInsuredCont();
		 readBeneficiaries();
		 readPremiumInf();
		 readPersonalInfo();
		 readagentInfo();
		 readphysicalinfo();
			
		}
	
	public void readLoginCredentials(String userID){	
		try {
			UserName = ReadData.getExcelData("Environment", UiMap.testDataExcelPath, userID, "UserName");
			Password = ReadData.getExcelData("Environment", UiMap.testDataExcelPath, userID, "Password");
			URL		 = ReadData.getExcelData("Environment", UiMap.testDataExcelPath, userID, "URL");
			System.out.println("url" +URL);
		} catch (IOException e) {
			System.out.println("Error occurred while retriving  URL, Username & password     " + e.getMessage());
			e.printStackTrace();
		}	
	}
	
	public void readAgencyCredentials(String userID) throws Exception{	
			aUserName = ReadData.getExcelData("AgencyLogin", UiMap.testDataExcelPath, userID, "UserName");
			aPassword = ReadData.getExcelData("AgencyLogin", UiMap.testDataExcelPath, userID, "Password");
			aName	  = ReadData.getExcelData("AgencyLogin", UiMap.testDataExcelPath, userID, "AgencyName");
		
	}
	
	
	public void readCaseInfoDetails() throws Exception {
		InsFirstName	=  ReadData.getExcelData(UiMap.testDataSheet, UiMap.testDataExcelPath, TestCaseID, "FirstName");
		InsLastName		=  ReadData.getExcelData(UiMap.testDataSheet, UiMap.testDataExcelPath, TestCaseID, "LastName");
		InsDOB  		=  ReadData.getExcelData(UiMap.testDataSheet, UiMap.testDataExcelPath, TestCaseID, "DOB");		
		Case_Desc 		=  ReadData.getExcelData(UiMap.testDataSheet, UiMap.testDataExcelPath, TestCaseID, "CaseDesc");
		InsGender 		=  ReadData.getExcelData(UiMap.testDataSheet, UiMap.testDataExcelPath, TestCaseID, "Gender");
		Sol_State  		=  ReadData.getExcelData(UiMap.testDataSheet, UiMap.testDataExcelPath, TestCaseID, "Sol_State");
		Product_Type 	=  ReadData.getExcelData(UiMap.testDataSheet, UiMap.testDataExcelPath, TestCaseID, "ProductType");
		Product 		=  ReadData.getExcelData(UiMap.testDataSheet, UiMap.testDataExcelPath, TestCaseID, "Product");						
	}
	
	
	public void readPrimaryInsured() throws Exception {
		primarySSN = ReadData.getExcelData(UiMap.testDataSheet, UiMap.testDataExcelPath, TestCaseID, "SSN");
		primaryCountry = ReadData.getExcelData(UiMap.testDataSheet, UiMap.testDataExcelPath, TestCaseID,
				"CountryOfBirth");
		primaryCitizen = ReadData.getExcelData(UiMap.testDataSheet, UiMap.testDataExcelPath, TestCaseID, "IsUSCitizen");
		primaryAddress = ReadData.getExcelData(UiMap.testDataSheet, UiMap.testDataExcelPath, TestCaseID, "Address");
		primaryCity = ReadData.getExcelData(UiMap.testDataSheet, UiMap.testDataExcelPath, TestCaseID, "City");
		primaryState = ReadData.getExcelData(UiMap.testDataSheet, UiMap.testDataExcelPath, TestCaseID, "State");
		primaryZipcode = ReadData.getExcelData(UiMap.testDataSheet, UiMap.testDataExcelPath, TestCaseID, "ZipCode");
		primaryPhoneNum = ReadData.getExcelData(UiMap.testDataSheet, UiMap.testDataExcelPath, TestCaseID, "PhoneNum");
		primaryMailAddr = ReadData.getExcelData(UiMap.testDataSheet, UiMap.testDataExcelPath, TestCaseID,
				"SameMailingAddress");
		primaryOwner = ReadData.getExcelData(UiMap.testDataSheet, UiMap.testDataExcelPath, TestCaseID, "PrimaryInsuredIsOwner");
		primarySecAdd = ReadData.getExcelData(UiMap.testDataSheet, UiMap.testDataExcelPath, TestCaseID, "SecAddress");
		BestNumToCallvalue=ReadData.getExcelData(UiMap.testDataSheet, UiMap.testDataExcelPath, TestCaseID, "BestNumToCall");
	}
	
	
	public void readPrimaryInsuredCont() throws Exception {
		priContEmpl = ReadData.getExcelData(UiMap.addPrimaryInsuredCont, UiMap.testDataExcelPath, TestCaseID, "CurrentlyEmployed");
		priContAnnIncome = ReadData.getExcelData(UiMap.addPrimaryInsuredCont, UiMap.testDataExcelPath, TestCaseID,
				"AnnIncome");
		priContNet = ReadData.getExcelData(UiMap.addPrimaryInsuredCont, UiMap.testDataExcelPath, TestCaseID, "NetWorth");
		priContHouseIncome = ReadData.getExcelData(UiMap.addPrimaryInsuredCont, UiMap.testDataExcelPath, TestCaseID, "HouseIncome");
		priContNetHouse = ReadData.getExcelData(UiMap.addPrimaryInsuredCont, UiMap.testDataExcelPath, TestCaseID, "HouseNetWorth");
		priContreason = ReadData.getExcelData(UiMap.addPrimaryInsuredCont, UiMap.testDataExcelPath, TestCaseID, "ReasonForAppln");
	}
	
	public void readBeneficiaries() throws Exception {
		beneRelation  = ReadData.getExcelData(UiMap.addBeneficiary, UiMap.testDataExcelPath, TestCaseID, "Relationship");
		beneFirstName = ReadData.getExcelData(UiMap.addBeneficiary, UiMap.testDataExcelPath, TestCaseID, "Fname");
		beneMiddleName = ReadData.getExcelData(UiMap.addBeneficiary, UiMap.testDataExcelPath, TestCaseID, "Mname");
		beneLastName = ReadData.getExcelData(UiMap.addBeneficiary, UiMap.testDataExcelPath, TestCaseID, "Lname");
		beneSSN = ReadData.getExcelData(UiMap.addBeneficiary, UiMap.testDataExcelPath, TestCaseID, "SSN");
		beneDOB = ReadData.getExcelData(UiMap.addBeneficiary, UiMap.testDataExcelPath, TestCaseID, "DOB");
		beneShare = ReadData.getExcelData(UiMap.addBeneficiary, UiMap.testDataExcelPath, TestCaseID, "Share");
		covFaceAmt =  ReadData.getExcelData(UiMap.addBeneficiary, UiMap.testDataExcelPath, TestCaseID, "FaceAmt");
		covDeathBO =  ReadData.getExcelData(UiMap.addBeneficiary, UiMap.testDataExcelPath, TestCaseID, "DBO");
	}
	
	public void readPremiumInf() throws Exception{
		preMode  = ReadData.getExcelData(UiMap.addPremiumInf, UiMap.testDataExcelPath, TestCaseID, "PremiumMode");
		prePlanMode  = ReadData.getExcelData(UiMap.addPremiumInf, UiMap.testDataExcelPath, TestCaseID, "Planned");
		preQuoted  = ReadData.getExcelData(UiMap.addPremiumInf, UiMap.testDataExcelPath, TestCaseID, "Quoted");
		preSource  = ReadData.getExcelData(UiMap.addPremiumInf, UiMap.testDataExcelPath, TestCaseID, "SourceOfFund");
		interestFixedTerm  = ReadData.getExcelData(UiMap.addPremiumInf, UiMap.testDataExcelPath, TestCaseID, "FixedInterest%");
	}
	
	public void readphysicalinfo() throws IOException
	{
		physicianType=	ReadData.getExcelData(UiMap.choosephysType, UiMap.testDataExcelPath, TestCaseID, "Type");
		physicianFirstName=	ReadData.getExcelData(UiMap.choosephysType, UiMap.testDataExcelPath, TestCaseID, "FirstName");
		physicianLastName=	ReadData.getExcelData(UiMap.choosephysType, UiMap.testDataExcelPath, TestCaseID, "LastName");
		physicianNumberAndStreet=	ReadData.getExcelData(UiMap.choosephysType, UiMap.testDataExcelPath, TestCaseID, "NumberAndStreet");
		physicianCity=	ReadData.getExcelData(UiMap.choosephysType, UiMap.testDataExcelPath, TestCaseID, "City");
		physicianState=	ReadData.getExcelData(UiMap.choosephysType, UiMap.testDataExcelPath, TestCaseID, "State");
		
		physicianZipCode=	ReadData.getExcelData(UiMap.choosephysType, UiMap.testDataExcelPath, TestCaseID, "ZipCode");
		physicianReasonLastConsulted=	ReadData.getExcelData(UiMap.choosephysType, UiMap.testDataExcelPath, TestCaseID, "ReasonLastConsulted");
		physicianDateLastConsulted=	ReadData.getExcelData(UiMap.choosephysType, UiMap.testDataExcelPath, TestCaseID, "DateLastConsulted");
		physicianOutcome=	ReadData.getExcelData(UiMap.choosephysType, UiMap.testDataExcelPath, TestCaseID, "Outcome");
		
		//public String getExcelData(String sheetName, String filePath,String rowData, String colData
	}
	
	public void readPersonalInfo() throws Exception {
		personalHeight  = ReadData.getExcelData(UiMap.addPhysicalInfo, UiMap.testDataExcelPath, TestCaseID, "HeightFt");
		personalInch  = ReadData.getExcelData(UiMap.addPhysicalInfo, UiMap.testDataExcelPath, TestCaseID, "HeightIn");
		personalWeight  = ReadData.getExcelData(UiMap.addPhysicalInfo, UiMap.testDataExcelPath, TestCaseID, "Weightlb");
		PersonalGainOrLossvalue  = ReadData.getExcelData(UiMap.addPhysicalInfo, UiMap.testDataExcelPath, TestCaseID, "GainOrLoss");
		PersonalGainOrLossDropDownvalue  = ReadData.getExcelData(UiMap.addPhysicalInfo, UiMap.testDataExcelPath, TestCaseID, "GainOrLossDropDown");
	}
	
	public void readagentInfo() throws Exception {
		agentKnown  = ReadData.getExcelData(UiMap.addagentInfo, UiMap.testDataExcelPath, TestCaseID, "Person Known period");
		agentPurpose  = ReadData.getExcelData(UiMap.addagentInfo, UiMap.testDataExcelPath, TestCaseID, "Purpose");
		agentFaceAmtDetermine  = ReadData.getExcelData(UiMap.addagentInfo, UiMap.testDataExcelPath, TestCaseID, "FaceAmtDet");
		agentAdditionalInfm  = ReadData.getExcelData(UiMap.addagentInfo, UiMap.testDataExcelPath, TestCaseID, "AddInf");
		agentRateClass  = ReadData.getExcelData(UiMap.addagentInfo, UiMap.testDataExcelPath, TestCaseID, "RateClass");
		agentUnderReq  = ReadData.getExcelData(UiMap.addagentInfo, UiMap.testDataExcelPath, TestCaseID, "UnderwrittingReq");
		agentIDProof = ReadData.getExcelData(UiMap.addagentInfo, UiMap.testDataExcelPath, TestCaseID, "PI ID Proof");
		//agentFirst = ReadData.getExcelData(UiMap.addagentInfo, UiMap.testDataExcelPath, TestCaseID, "First Name");
		//agentLast = ReadData.getExcelData(UiMap.addagentInfo, UiMap.testDataExcelPath, TestCaseID, "Last Name");
		agentNumber = ReadData.getExcelData(UiMap.addagentInfo, UiMap.testDataExcelPath, TestCaseID, "Agent Number");
		agencyNumber = ReadData.getExcelData(UiMap.addagentInfo, UiMap.testDataExcelPath, TestCaseID, "Agency Number");
		agentComp = ReadData.getExcelData(UiMap.addagentInfo, UiMap.testDataExcelPath, TestCaseID, "Agent Compensation");
		spAgentName = ReadData.getExcelData(UiMap.addagentInfo, UiMap.testDataExcelPath, TestCaseID, "Split Agent Name");
		spAgentPH = ReadData.getExcelData(UiMap.addagentInfo, UiMap.testDataExcelPath, TestCaseID, "Split Agent Phone");
		spAgentNumDD = ReadData.getExcelData(UiMap.addagentInfo, UiMap.testDataExcelPath, TestCaseID, "Split Agent Number DD");
		spAgentNum = ReadData.getExcelData(UiMap.addagentInfo, UiMap.testDataExcelPath, TestCaseID, "Split Agent Number");
		spAgentComp = ReadData.getExcelData(UiMap.addagentInfo, UiMap.testDataExcelPath, TestCaseID, "Split Agent Comp");
		}
	
	
	
	}
	
		
	

