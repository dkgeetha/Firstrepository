package eApp.Case;

public class RecursionTest2 {

	
		public RecursionTest2(int info)
		{
			printme(info);
		}
		public static void main(String[] args)
		{
			RecursionTest2 re = new RecursionTest2(1);
		}
		public void printme(int x)
		{
			for(int y=0;y<10;y++)
			{
				printme(y);
				System.out.println(y);
				
			}
		}
	}


