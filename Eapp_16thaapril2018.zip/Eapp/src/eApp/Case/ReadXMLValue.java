package eApp.Case;
import java.io.File;
import java.io.IOException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
/**
 * This Class used to Read the Value from the XML File
 * @author ha0127
 *
 */

public class ReadXMLValue {
	
	/**
	 * Method  used to Read the Value from the XML File
	 * @param file - Path of XML file
	 * @param nodeName -  Main element Node 
	 * @param idName - id name of Main element node (ex: id=test)
	 * @param subNode - Child Node under main Node
	 * @param elementName - Name of element where data to be Read
	 * @return - String value 
	 */
	public String result[] =new String[2];
	public String val1 =null;
	public String val2 = null;;
	public String id_selection = null;
	public String idName_select = null;
	public  String[] Get_Xml_Value(File file,String nodeName, String idName , String subNode , String elementName)
	{

try {
	

		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = null;
		try {
			dBuilder = dbFactory.newDocumentBuilder();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		}
		Document doc= null;
		try {
			doc = dBuilder.parse(file);
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}


		doc.getDocumentElement().normalize();
		
		//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
		
		if(idName!=null)
		{
			String id_List[] = idName.concat("=").split("=");
			if(id_List.length >1)
			{
				id_selection = id_List[0];
				System.out.println("Id from list" + id_selection);
				idName_select = id_List[1];
			}else{
				id_selection = "id";
				System.out.println("Id" + id_selection);
				idName_select=idName;
			}
		}
		
		
		NodeList nList = doc.getElementsByTagName(nodeName);
		//System.out.println("----------------------------");
		int totalTags=  nList.getLength();
		for(int i=0; i<totalTags; i++)
		{
			if(idName!=null){
			String nodeNameValue = nList.item(i).getAttributes().getNamedItem(id_selection).getNodeValue();
			//System.out.println(nodeName);
			if(nodeNameValue.equalsIgnoreCase(idName_select))
			{ 
			if(subNode!=null)
			{
				NodeList nList2 = nList.item(i).getChildNodes();
				int totalTags2=  nList2.getLength();
				for(int j=0; j<totalTags2; j++)
				{
					String subTagName = nList2.item(j).getNodeName();
					//
					//System.out.println(subTagName);
					if(subTagName.equalsIgnoreCase(subNode))
					{
						result= findelement(nList2,j,elementName);
					}
				}
				}
				else
				{
						result= findelement(nList,i,elementName);
				}
				}
				}
			else
			{
				if(subNode!=null)
				{
					NodeList nList2 = nList.item(i).getChildNodes();
					int totalTags2=  nList2.getLength();
					for(int j=0; j<totalTags2; j++)
					{
						String subTagName = nList2.item(j).getNodeName();
						//
						//System.out.println(subTagName);
						if(subTagName.equalsIgnoreCase(subNode))
						{
							result = findelement(nList2,j,elementName);
						}
					}
					}
					else
					{
							result= findelement(nList,i,elementName);
					}
			}
		}
		return result;
	} catch (Exception e) {
		System.out.println("Error Occurred in XML Reading function: May be these elements not available: "+nodeName+" : "+idName+" : "+subNode+" : "+elementName );
		return result;
	}
}

			
public String[] findelement(NodeList nList2,int j,String elementName){
		NodeList nList3 = nList2.item(j).getChildNodes();
		if(elementName!=null)
		{
			int totalTags3=  nList3.getLength();
			//System.out.println(totalTags3);
			for(int k=0; k<totalTags3; k++)
			{
				String eleName = nList3.item(k).getNodeName();
				if(eleName.equalsIgnoreCase(elementName))
				{				
							if(nList3.item(k).getAttributes().getLength()>0){
								//System.out.println(true);
								val2= nList3.item(k).getAttributes().getNamedItem("tc").getNodeValue();}
							else{
								val2=null;
							}
						
					val1= nList3.item(k).getTextContent();
					break;
				}
			}
		}else
		{
			val1= nList2.item(j).getTextContent();
		}
		result[0]=val1;
		result[1]=val2;
		return result;
}
}
		
		
		
		
		