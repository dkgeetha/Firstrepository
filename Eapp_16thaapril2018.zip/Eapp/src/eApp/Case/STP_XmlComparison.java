package eApp.Case;

import java.io.File;
import org.testng.Reporter;
import HTML_Report.Report;
import HTML_Report.Status;
import Utilities.ExcelFunctions;

public class STP_XmlComparison {
	public boolean result = false;
	StringBuilder failureReason, subfaiReason;
	ReadXMLValue readxmlValue;
	public String testCaseName;
	public Report report;
	public static  ExcelFunctions readData = new ExcelFunctions();
	public static  ResuableFunctions reuse = new ResuableFunctions();
	public Status Xmlcomp,TcComp = Status.FAIL;
	public static  int XmlTC;
	
	public String  Comparing_XMLData(String TransID,Report reportevent,String testCase) throws Exception {
		report = reportevent;
		testCaseName = testCase;
		result = false;
		failureReason = new StringBuilder();
		File ofile = null;
		readxmlValue = new ReadXMLValue();
		new ExcelData().readAllDetails(testCaseName);
		//TransID = "2000550X";
		try {
			System.out.println("Present Iteration Number is : " + testCase);
			
			ofile = reuse.getTheNewestFile("\\C:\\Users\\ha0127\\Desktop\\STP", "xml",TransID); // File path of XML
			String xmlFileName = ofile.getName();
			System.out.println("Verifying  the follwing file: " + xmlFileName);
			System.out.println("-------------------------------------------");
			
			// Comparing 
		/*	Verify_Strings("PolicyID",reuse.GetXML_Tags_and_Data(ofile, "PolicyID"),TransID,"");
			Verify_Strings("LineofBusiness",reuse.GetXML_Tags_and_Data(ofile, "Annuity"), "Annuity",findExceltc("Annuity"));
			Verify_Strings("IndexedAnn",reuse.GetXML_Tags_and_Data(ofile, "IndexedAnnuity"),"Indexed Annuities",findExceltc("Indexed Annuities"));
			Verify_Strings("PlanSelected",reuse.GetXML_Tags_and_Data(ofile, "PlanSelected"), ExcelData.Product,findExceltc(ExcelData.Product));
			Verify_Strings("SolicitationState",reuse.GetXML_Tags_and_Data(ofile, "SolicitationState"), ExcelData.Sol_State,findExceltc(ExcelData.Sol_State));
			Verify_Strings("PaymentFrequency",reuse.GetXML_Tags_and_Data(ofile, "PaymentFrequency"), ExcelData.PrPmtfrq,findExceltc(ExcelData.PrPmtfrq));
			Verify_Strings("PaymentAmount",reuse.GetXML_Tags_and_Data(ofile, "PaymentAmount"), ExcelData.PrPmtAmt,findExceltc(ExcelData.PrPmtAmt));
			Verify_Strings("PaymentMethod",reuse.GetXML_Tags_and_Data(ofile, "PaymentMethod"), ExcelData.PrPmtMethod,findExceltc(ExcelData.PrPmtMethod));
			Verify_Strings("CommissionOption",reuse.GetXML_Tags_and_Data(ofile, "CommissionOption"),"Trail Option",findExceltc("Trail Option"));
			Verify_Strings("PartyTypeCode",reuse.GetXML_Tags_and_Data(ofile, "AnnSameAsOwner"),"Person",findExceltc("Person"));
			Verify_Strings("PlanQualification",reuse.GetXML_Tags_and_Data(ofile, "PlanQualification"), ExcelData.PlanQual,findExceltc(ExcelData.PlanQual));
			Verify_Strings("Stateofbusiness",reuse.GetXML_Tags_and_Data(ofile, "Stateofbusiness"),ExcelData.StateofBus,findExceltc(ExcelData.StateofBus));
			Verify_Strings("DeclaredPer",reuse.GetXML_Tags_and_Data(ofile, "DeclaredAccPer"),ExcelData.DecIntAmt,"");
			Verify_Strings("RusOpt1",reuse.GetXML_Tags_and_Data(ofile, "RusOpt1"), ExcelData.RusOption1Index,"");
			Verify_Strings("RusOpt2",reuse.GetXML_Tags_and_Data(ofile, "RusOpt2"), ExcelData.RusOption2Index,"");
			Verify_Strings("RusEnd",reuse.GetXML_Tags_and_Data(ofile, "RusEnd"), ExcelData.RusEndIndex,"");
			Verify_Strings("SPOpt1",reuse.GetXML_Tags_and_Data(ofile, "SPOpt1"), ExcelData.SPOption1Index,"");
			Verify_Strings("SPOpt2",reuse.GetXML_Tags_and_Data(ofile, "SPOpt2"), ExcelData.SPOption2Index,"");
			Verify_Strings("SPAvg",reuse.GetXML_Tags_and_Data(ofile, "SPAvg"), ExcelData.SPAvgIndex,"");
			Verify_Strings("SPEnd",reuse.GetXML_Tags_and_Data(ofile, "SPEnd"),ExcelData.SPEndIndex,"");
			Verify_Strings("DeclaredPerProduct",reuse.GetXML_Tags_and_Data(ofile, "DeclaredAccProd"),findExceltc("DeclaredAccPer"),"");
			Verify_Strings("RusOpt1Product",reuse.GetXML_Tags_and_Data(ofile, "RusOpt1Prod"),findExceltc("RusOpt1"),"");
			Verify_Strings("RusOpt2Product",reuse.GetXML_Tags_and_Data(ofile, "RusOpt2Prod"),findExceltc("RusOpt2"),"");
			Verify_Strings("RusEndProduct",reuse.GetXML_Tags_and_Data(ofile, "RusEndProd"),findExceltc("RusEnd"),"");
			Verify_Strings("SPOpt1Product",reuse.GetXML_Tags_and_Data(ofile, "SPOpt1Prod"),findExceltc("SPOpt1"),"");
			Verify_Strings("SPOpt2Product",reuse.GetXML_Tags_and_Data(ofile, "SPOpt2Prod"),findExceltc("SPOpt2"),"");
			Verify_Strings("SPAvgProduct",reuse.GetXML_Tags_and_Data(ofile, "SPAvgProd"),findExceltc("SPAvg"),"");
			Verify_Strings("SPEndProduct",reuse.GetXML_Tags_and_Data(ofile, "SPEndProd"),findExceltc("SPEnd"),"");
			Verify_Strings("Ann_Fname",reuse.GetXML_Tags_and_Data(ofile, "Ann_Fname"), ExcelData.AnnFirstName,findExceltc(""));
			Verify_Strings("Ann_LastName",reuse.GetXML_Tags_and_Data(ofile, "Ann_LastName"),ExcelData.AnnLastName,findExceltc(""));
			Verify_Strings("Ann_Add1",reuse.GetXML_Tags_and_Data(ofile, "Ann_Add1"), ExcelData.AnnAddr1,findExceltc(""));
			Verify_Strings("Ann_Gender",reuse.GetXML_Tags_and_Data(ofile, "Ann_Gender"), ExcelData.AnnGender,findExceltc(ExcelData.AnnGender));
			Verify_Strings("Ann_DOB",reuse.GetXML_Tags_and_Data(ofile, "Ann_DOB"), ExcelData.AnnDOB,findExceltc(""));
			Verify_Strings("Ann_City",reuse.GetXML_Tags_and_Data(ofile, "Ann_City"), ExcelData.AnnCity,findExceltc(""));
			Verify_Strings("Ann_ZIP",reuse.GetXML_Tags_and_Data(ofile, "Ann_Zip"), ExcelData.AnnZipcode,findExceltc(""));
			Verify_Strings("Ann_State",reuse.GetXML_Tags_and_Data(ofile, "Ann_State"), ExcelData.StateofBus,findExceltc(ExcelData.StateofBus));
			Verify_Strings("AnnTaxIDSSNValue",reuse.GetXML_Tags_and_Data(ofile, "AnnTaxIDSSNValue"), ExcelData.AnnSSNTaxVal,findExceltc(""));
			Verify_Strings("AnnTaxIDSSNButton",reuse.GetXML_Tags_and_Data(ofile, "AnnTaxIDSSNButton"), "Social Security Number US",findExceltc("Social Security Number US"));*/

			return "PASS";
		
		} catch (Exception e) {
			System.out.println("Exception in XML File Verification " + e.getMessage());
			e.printStackTrace();
			Reporter.log(e.getMessage());
			failureReason.append("Error occured in XML Comparision Function  \n"+e.getMessage());
			return failureReason.toString();

		}
	}
		/**
		 * Function to Verify the two strings and write the result in Excel Sheet
		 * 
		 * @param fieldName
		 *            - Field under verification
		 * @param xmlvalue
		 *            - xml string
		 * @param excelvalue
		 */
		public void Verify_Strings(String fieldName, String[] xmlvalue, String excelvalue, String exceltc) {
			if(excelvalue.length()!=0 && !excelvalue.equals(null)){
			System.out.println(fieldName + ": ");
			System.out.println("XML: " + xmlvalue[0] + "Excel: " + excelvalue);
			System.out.println("XMLTC: " + xmlvalue[1] + "Excel: " + exceltc);
			int lastRow = readData.Last_Row(UiMap.Reg_ResultsExcelpath, "Comparing_Result");
			lastRow = lastRow+1;
			//System.out.println("Last row is : "+lastRow);
			readData.writeResult_UsingIndex("Result", lastRow, 0,fieldName );
			readData.writeResult_UsingIndex("Result", lastRow, 1, testCaseName);
			readData.writeResult_UsingIndex("Result", lastRow, 2, xmlvalue[0]);
			readData.writeResult_UsingIndex("Result", lastRow, 3, excelvalue);
			readData.writeResult_UsingIndex("Result", lastRow, 5, xmlvalue[1]);
			readData.writeResult_UsingIndex("Result", lastRow, 6, exceltc);
			
			if(xmlvalue[0] != null)
			{
				if (xmlvalue[0].equalsIgnoreCase(excelvalue)) {					
					readData.writeResult_UsingIndex("Result", lastRow, 4, "Equal");
					Xmlcomp = Status.PASS;
					System.out.println(fieldName + " field  Verified Sucessfully");
				}
				else {				
					readData.writeResult_UsingIndex("Result", lastRow, 4, "Different");
					Xmlcomp = Status.FAIL;
					System.out.println(fieldName + " field  Contains Different Value");
				}

				if(xmlvalue[1] != null)
					{
				if (xmlvalue[1].equals(exceltc)) {							
					readData.writeResult_UsingIndex("Result", lastRow, 7, "Equal");
					TcComp = Status.PASS;
					System.out.println(fieldName + " field  Verified Sucessfully");
						}
				else {
					readData.writeResult_UsingIndex("Result", lastRow, 7, "Different");
					TcComp = Status.FAIL;
					System.out.println(fieldName + " field  Contains Different Value");
						}
					}				
				else
				{
					xmlvalue[1] = "";
					if(xmlvalue[1].equals("")&&exceltc.equals("")){
					TcComp = Status.PASS;}
					readData.writeResult_UsingIndex("Result", lastRow, 7, "Null to Compare");
				}
				
			//	report.UpdateResult(testCaseName,fieldName,excelvalue,xmlvalue[0],Xmlcomp,xmlvalue[1],exceltc,TcComp);
				}				
			else
			{
				readData.writeResult_UsingIndex("Result", lastRow, 4, "Null to Compare");
				System.out.println(fieldName +" Field Value is null to Compare");
			}
			

			System.out.println("---------------------------------------");
			System.out.println();
		}
		}
	

public String findExceltc(String FieldName) throws Exception{
	
	if(FieldName!=null){
	String tc1 = readData.getExcelData("TCVal", UiMap.testDataExcelPath, FieldName, "Value");
	if(tc1.equals("Value"))
	{
		return "";
	}
	else 
	{
		return tc1.trim();
	}
	}
	return "";
}
}
