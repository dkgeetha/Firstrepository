/**
 * @author ha0127
 */
package eApp.Case;



import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList; 
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.logging.log4j.core.util.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.sun.jna.platform.win32.WinDef.UINT_PTR;

import Utilities.ExcelFunctions;
import Utilities.WebDriverUtil;

public class EAppCaseCreation {
	public WebDriver driver;
	public WebDriverUtil objWait;
	public ExcelData getData;
	public String AddBeneficiary,AddContBeneficiary,Result,TCID,TestcaseID;
	public String[] DOB,PD,OD,DOI,AnnownProducts,Objectives,SkipMonths,AnnDOB,OwnerDOT,CheckReason,AMD,ASD,BenDOB;
	public static  ExcelFunctions WriteData = new ExcelFunctions();
	public static  ResuableFunctions reuse = new ResuableFunctions();
	public static String no = "No";
	public static String yes = "Yes";
	public static String errorMessage = null;
	ExcelData newobj=new ExcelData();
	String comparison;
	
	public String newCaseCreation (WebDriver BrowserDriver,WebDriverUtil BrowserobjWait,String TCID, ExcelData getData) throws Exception 
	{
		String result = null;
		try {
		errorMessage = null;
		driver =  BrowserDriver;
		objWait = BrowserobjWait;
		TCID = TestcaseID;
		//report = Htmlreport;
		Result = "Fail";
		objWait.waitUntilElementVisible(By.cssSelector(UiMap.WbLnk_NewCase), 20);
		driver.findElement(By.cssSelector(UiMap.WbLnk_NewCase)).click();
		String comparison= newobj.Product_Type.toString();
		
		eAppCaseInformation();
		preQualification();
		primaryInsured(); 
		primaryInsuredCont();
		beneficiaryPrimaryInsured(); 
		//ResuableFunctions.callcoverageInformation();
		coverageInformation();
		premiumInformation(); 
		
		
		//String comparison= newobj.Product_Type.toString();
		//EAppCaseCreation covinfopage=new EAppCaseCreation();
		
		if(comparison.equals("Indexed Universal Life"))
		{
		
			interestCrediting();
		}
		//interestCrediting(); //This is extra screen for IndexedUniversalLife pdt type with LSW SecurePlus Provider pdt

		existingInsurance();
		physicianInfo();
		personalInfo(); 
		lifeStyle();
		medicalQuestion();
		if(comparison.equals("Term Insurance")|| comparison.equals("Fixed Universal Life"))
		{
		
			chronicQuestion();
		}
		
		objWait.waitFor(1);
		noticeAndConsent();  
		agentReport(); 
		agentReportCont(); 
		agentReportInf(); 
		attachments();  
		validatelock();
		agntInst();
		signMeth(); 
		esigDis();
		objWait.waitFor(1);
		termsUse();
		objWait.waitFor(2);
		eSign();
		
		/*termsUse();
		esigDis();
		eSign();*/
		//String result = STP_Attachments();
		result = "pass";
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			throw new Exception(errorMessage);
		}
		return result;
		
		}

	/**
	 * check for the list of products for the given agency.
	 * @param webdriver
	 * @param wait
	 * @param agencyName
	 * @return
	 * @throws Exception
	 */
	
	//================Start - Other pdts========================
	public boolean productForAgency(WebDriver webdriver, WebDriverUtil wait, String agencyName) throws Exception {
		List<String> termIns = new ArrayList<String>();
		List<String> termProduct = new ArrayList<String>();
		List<String> agencyProduct = new ArrayList<String>();
		if (agencyName.equals("cthree4")) {
			agencyProduct.add("Term Insurance");
			agencyProduct.add("Fixed Universal Life");
			agencyProduct.add("Indexed Universal Life");
			termProduct.add("LSW Level Term 10-G");
			termProduct.add("LSW Level Term 15-G");
			termProduct.add("LSW Level Term 15-NG");
			termProduct.add("LSW Level Term 20-G");
			termProduct.add("LSW Level Term 20-NG");
			termProduct.add("LSW Level Term 30-NG");
			termProduct.add("LSW Foundation");
			termProduct.add("LSW SecurePlus Provider");

		} else {
			agencyProduct.add("Indexed Universal Life");
			termProduct.add("LSW Living Life");
			//termProduct.add("LSW SecurePlus Provider");
		}

		driver = webdriver;
		objWait = wait;
		System.out.println("Entered in Case Information Screen");
		objWait.waitUntilElementVisible(By.cssSelector(UiMap.wbFrame), 2);
		driver.switchTo().frame(driver.findElement(By.cssSelector(UiMap.wbFrame)));
		clickElementUsingXpath(UiMap.selectState);
		clickElementUsingXpath("//span[text()='" + "California" + "']");
		for (int k = 0; k < agencyProduct.size(); k++) {
			clickElementUsingXpath(UiMap.productPanel);
			try {
				clickElementUsingXpath(
						"//div[@class='btn-group bootstrap-select form-control open']/div/ul/li/a/span[text()='"
								+ agencyProduct.get(k) + "']");
			} catch (Exception ex) {
				selectElement("#ddlProductType.form-control.selectpicker", agencyProduct.get(k));
			}

			objWait.waitUntilElementVisible(By.cssSelector(UiMap.wbLnk_AvlProducts), 300);
			objWait.waitFor(5);

			driver.findElement(By.cssSelector(UiMap.wbLnk_AvlProducts)).click();

			objWait.waitFor(3);
			// No.of rows
			List<WebElement> row_table = driver.findElements(By.xpath(UiMap.wbTbl_Prod_rows));
			int rows_count = row_table.size();
			// No.of cols
			WebElement Producttable = driver.findElement(By.xpath(UiMap.wbTbl_Prod_cols));
			List<WebElement> col_table = Producttable.findElements(By.tagName("th"));
			int cols_count = col_table.size();
			// To select specific product from list
			for (int row = 1; row <= rows_count; row++) {
				for (int col = 1; col <= cols_count; col++) {
					String celtext = driver
							.findElement(By.xpath(".//*[@id='GridView1']/tbody/tr[" + row + "]/td[" + col + "]"))
							.getText();
					if (celtext.startsWith("LSW")) {
						termIns.add(celtext.trim());
					}
				}
			}
		}
		if (termIns.containsAll(termProduct)) {
			
			termProduct.get(0);
			return true;
		} 
		
		return false;

	}
	//================Start - Other pdts========================
			
	///================================Start - Case Creation method implementation till above===========================
	public void eAppCaseInformation() throws Exception
	{
		try {
		System.out.println("Entered in Case Information Screen");
		Thread.sleep(1000);
		objWait.waitUntilElementVisible(By.cssSelector(UiMap.wbFrame), 2);
		driver.switchTo().frame(driver.findElement(By.cssSelector(UiMap.wbFrame)));
		textInputUsingCss(UiMap.wbtxt_InsFirstName, ExcelData.InsFirstName);
		//textInputUsingxpath(UiMap.webtxt_InsFirstName, ExcelData.InsFirstName);
		
		driver.findElement(By.cssSelector(UiMap.wbtxt_InsLastName)).sendKeys(ExcelData.InsLastName);
		
		dateFieldCssPath(UiMap.wbDate_InsuredDOB,ExcelData.InsDOB);
		
		driver.findElement(By.cssSelector(UiMap.wbtxt_InsuredAge)).click();
		clickElementUsingXpath(UiMap.wbBtn_Ins_Gender);
		
		if (ExcelData.InsGender.equalsIgnoreCase("Male"))
		{
			clickElementUsingXpath(UiMap.wbdw_Insured_Male);
		}
		else
		{
			clickElementUsingXpath(UiMap.wbdw_Insured_Female);
		}
		
		objWait.waitUntilElementVisible(By.cssSelector(UiMap.wbtxt_Case_Desc), 3);
		driver.findElement(By.cssSelector(UiMap.wbtxt_Case_Desc)).sendKeys(ExcelData.Case_Desc);
		objWait.waitFor(2);
		
		//selectElementUsingXpath("//*[@id='UpdatePanel1']/div/button/span[1]","Texas");
		//selectElementUsingXpath("//*[@id='UpdatePanel2']/div/button/span[1]","Indexed Universal Life");
		
		clickElementUsingXpath("//*[@id='UpdatePanel1']");
		clickElementUsingXpath("//span[text()='"+ExcelData.Sol_State +"']");
		//clickElementUsingXpath("//div/button/span[1][text()='Texas']");
		objWait.waitFor(5);
		clickElementUsingXpath("//*[@id='UpdatePanel2']");
		clickElementUsingXpath("//span[contains(.,'"+ExcelData.Product_Type+"')]");
		
		objWait.waitUntilElementEnabled(By.cssSelector(UiMap.wbLnk_AvlProducts),300);
		objWait.waitFor(5);
		
		driver.findElement(By.cssSelector(UiMap.wbLnk_AvlProducts)).click();
		
		objWait.waitFor(3);
        //No.of rows  
        List <WebElement> row_table = driver.findElements(By.xpath(UiMap.wbTbl_Prod_rows)); 
        int rows_count =  row_table.size();   
        //No.of cols
        WebElement Producttable = driver.findElement(By.xpath(UiMap.wbTbl_Prod_cols));
		List<WebElement> col_table = Producttable.findElements(By.tagName("th"));
		int cols_count = col_table.size();
       //To select specific product from list
        for (int row=1; row<=rows_count; row++){
        	for (int col=1; col<=cols_count;col++)
        	{
        		 String celtext = driver.findElement(By.xpath(".//*[@id='GridView1']/tbody/tr["+row+"]/td["+col+"]")).getText();
        		 if(celtext.trim().equalsIgnoreCase(ExcelData.Product))
     		    {
        			 int Selectcol=col+1;
        			 driver.findElement(By.xpath(".//*[@id='GridView1']/tbody/tr["+row+"]/td["+Selectcol+"]/input")).click();
        			 rows_count=1;
        			break;
     		    }      		        		 
        	} 		   
        }
        driver.switchTo().parentFrame();
        driver.switchTo().defaultContent();
		}catch(Exception Ex){
			errorMessage ="Error occured in case Information Page";
			throw new Exception();
		}
	
	}
	
	
	
	public void preQualification() throws Exception {
		try {
			System.out.println("Entered in Pre-Qualification Screen");
			objWait.waitFor(20);
			
			objWait.waitUntilElementVisible(By.cssSelector(UiMap.wbFrame), 5);
			driver.switchTo().frame(driver.findElement(By.cssSelector(UiMap.wbFrame)));
			objWait.waitUntilElementVisible(By.cssSelector(UiMap.cond_Apply), 100);
			driver.findElement(By.cssSelector(UiMap.cond_Apply)).click();
			driver.findElement(By.cssSelector(UiMap.next)).click();
			System.out.println("Entered in Pre-Qualification Screen completed");
			Thread.sleep(10000);
		} 
		catch (Exception ex) {
			errorMessage = "Error occured in Plan Qualification Screen";
			throw new Exception();
		}

	}
	
	public void primaryInsured() throws Exception{
		try {
		System.out.println("Primary Insured");
		objWait.waitUntilElementVisible(By.cssSelector(UiMap.primaryInsured), 100);
		textInputUsingCss(UiMap.primarySSN, ExcelData.primarySSN);
		selectElement(UiMap.primaryCountry, ExcelData.primaryCountry);
		
		if("Yes" .equalsIgnoreCase(ExcelData.primaryCitizen))
		{
		radiobtnClick(UiMap.primaryCitizen);
		}
		textInputUsingCss(UiMap.primaryAddress, ExcelData.primaryAddress);
		Thread.sleep(1000);
		textInputUsingCss(UiMap.primaryCity, ExcelData.primaryCity);
		selectElement(UiMap.primaryState, ExcelData.primaryState);
		textInputUsingCss(UiMap.primaryZipcode, ExcelData.primaryZipcode);
		Thread.sleep(2000);
		 comparison= newobj.Product.toString();
				
		
		
		if(comparison.equals("PeakLife NL"))
		{
		
			selectElement(UiMap.primaryPhoneToContactForPeak, "Home");
		}
		else
		{
		//selectElement(UiMap.primaryPhoneToContact, "Home"); //IE - Not working
		//clickElementUsingXpath(UiMap.primaryPhoneToContact); //*[@id='lb_179']/option[text()='Home']
		//clickElementUsingXpath("//*[@id='lb_179']/option[text()='']");
			clickElementUsingXpath("//*[@id='lb_179']/option[text()='"+ExcelData.BestNumToCallvalue+"']");
		
		
		}
		textInputUsingCss(UiMap.primaryPhoneNum, ExcelData.primaryPhoneNum); 
	//	textInputUsingxpath( UiMap.emailaddress,ExcelData.emailvalue);
		
		driver.findElement(By.xpath("//*[@id='flda_117']")).sendKeys("geetha@nationallife.com");
		if("Yes" .equalsIgnoreCase(ExcelData.primaryMailAddr)) {
			radiobtnClick(UiMap.primaryMailAddr);
			}
		if("Yes" .equalsIgnoreCase(ExcelData.primaryOwner)) {
			radiobtnClick(UiMap.primaryOwner);
			}
			radiobtnClick(UiMap.primaryJointOwner);	
			objWait.waitFor(10);
		if("No" .equalsIgnoreCase(ExcelData.primarySecAdd)) {
			radiobtnClick(UiMap.primarySecAdd);
			}
		//driver.findElement(By.cssSelector(UiMap.primaryNext)).click();
		//driver.findElement(By.cssSelector(UiMap.primaryNextxpath)).click();
	//	//WebElement element = driver.findElement(By.id("gbqfd"));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", "btn_16");
		//xpath - //*[@id="btn_16"]
		System.out.println("Primary Insured Screen completed");
		
		}
		
		catch(Exception ex){
			errorMessage = "Error occured in Primary Insured";
			//throw new Exception();
		}
		
	}

	public void primaryInsuredCont() throws Exception {
		try {
			System.out.println("Primary Insured Cont");
			Thread.sleep(10000);
			objWait.waitUntilElementVisible(By.cssSelector(UiMap.priCont), 100);
			radiobtnClick(UiMap.priContDriverLic);
			selectElement(UiMap.priContEmpl, ExcelData.priContEmpl);
			textInputUsingCss(UiMap.priContAnnIncome, ExcelData.priContAnnIncome);
			textInputUsingCss(UiMap.priContNet, ExcelData.priContNet);
			textInputUsingCss(UiMap.priContHouseIncome, ExcelData.priContHouseIncome);
			textInputUsingCss(UiMap.priContNetHouse, ExcelData.priContNetHouse);
			radiobtnClick(UiMap.priContInterview);
			radiobtnClick(UiMap.priContCopy);
			selectElement(UiMap.priContreason, ExcelData.priContreason);
			//driver.findElement(By.cssSelector(UiMap.priContNext)).click();
			driver.findElement(By.cssSelector(UiMap.priContNextxpath)).click();
			////*[@id="btn_7"]/span
			System.out.println("Primary Insured Cont screen completed");
			Thread.sleep(10000);
		} catch (Exception ex) {
			errorMessage = "Error occured in Primary Insured Contd Page";
			throw new Exception();
		}

	}
	public void beneficiaryPrimaryInsured() throws Exception{
	try{
		System.out.println("Beneficiaries - Primary Insured");
		objWait.waitUntilElementVisible(By.cssSelector(UiMap.benePriInsured), 100);
		
		System.out.println("handle"+driver.getWindowHandle());
		driver.findElement(By.cssSelector(UiMap.benePriAdd)).click();
		String parentWindowHandler = driver.getWindowHandle(); // Store your parent window
		System.out.println("Parent " +parentWindowHandler); //Till here, it is working
		String subWindowHandler = null;

		Set<String> handles = driver.getWindowHandles(); // get all window handles
		Iterator<String> iterator = handles.iterator();
		while (iterator.hasNext()){
		    subWindowHandler = iterator.next();//Ans: CDwindow-81F064DAAB58FCE75C573B1C6D84557B,
		}
		driver.switchTo().window(subWindowHandler);
		driver.switchTo().frame(driver.findElement(By.cssSelector("iframe#modalIframe")));
		Thread.sleep(1000);
		selectElement(UiMap.beneRelation, ExcelData.beneRelation);
		textInputUsingCss(UiMap.beneFirstName, ExcelData.beneFirstName);
		textInputUsingCss(UiMap.beneMiddleName, ExcelData.beneMiddleName);
		textInputUsingCss(UiMap.beneLastName, ExcelData.beneLastName);
		textInputUsingCss(UiMap.beneSSN, ExcelData.beneSSN);
		dateFieldCssPath(UiMap.beneDOB, ExcelData.beneDOB);
		textInputUsingCss(UiMap.beneShare, ExcelData.beneShare);
		driver.findElement(By.cssSelector(UiMap.beneResiAddr)).click(); 
		driver.switchTo().defaultContent();
		Thread.sleep(1000);
		driver.findElement(By.cssSelector(UiMap.beneSave)).click();
		Thread.sleep(1000);
		driver.switchTo().window(parentWindowHandler);
		Thread.sleep(1000);
		driver.switchTo().frame(driver.findElement(By.cssSelector("iframe#CossScreenFrame.preview-runtime__iframe")));
		Thread.sleep(1000);
		radiobtnClick(UiMap.beneContBeneficiary);
		driver.findElement(By.cssSelector(UiMap.beneNext)).click();
		Thread.sleep(10000);
	}catch(Exception ex){
		errorMessage = "Error occured in Beneficiaries - Primary Insured page";
		throw new Exception();
	}
	}
	
	public void coverageInformation() throws Exception {
		try {
			
			
			System.out.println("Coverage Information");
			Thread.sleep(1000);
			
			//ExcelData newobj=new ExcelData();
		 comparison= newobj.Product_Type.toString();
			
			
			if(comparison.equals("Indexed Universal Life")||comparison.equals("Fixed Universal Life"))
			{
			
				covInfoForIndexedUniversalLifePdt();
			}
			else
			{
				System.out.println("Term Insurance");
			//driver.switchTo().frame(driver.findElement(By.cssSelector(UiMap.covInformFrame)));
			//objWait.waitUntilElementVisible(By.xpath(UiMap.covnewxpath), 150);
			
			//objWait.waitUntilElementVisible(By.cssSelector(UiMap.covInform), 100);
			textInputUsingCss(UiMap.covFaceAmt, ExcelData.covFaceAmt);
			
			//selectElement(UiMap.covDeathBO, ExcelData.covDeathBO);
		//	driver.findElement(By.xpath(UiMap.cashvalue)).click();//Geetha
		//	driver.findElement(By.xpath(UiMap.illustration)).click();//Geetha
			//radiobtnClick(UiMap.covInsutest);
			//driver.findElement(By.cssSelector(UiMap.covDeathreq)).click();
			
			radiobtnClick(UiMap.covIllustration);
			driver.findElement(By.cssSelector(UiMap.covNext)).click();
			System.out.println("Coverage Information completd");
			Thread.sleep(10000);
			}
			
		} 
		catch (Exception ex) 
		{
			errorMessage = "Error occured in Coverage Information page";
			throw new Exception();
		}

	}
	//rough
	public void covInfoForIndexedUniversalLifePdt() throws Exception
	 {
		
		textInputUsingCss(UiMap.covFaceAmount, ExcelData.covFaceAmt);
		
		selectElement(UiMap.covDeathBO, ExcelData.covDeathBO);
		
		String AvailPdt= newobj.Product.toString();
		if(AvailPdt.equals("LSW SecurePlus Provider") && comparison.equals("Indexed Universal Life"))
		{
		driver.findElement(By.xpath(UiMap.cashvalue)).click();
		//driver.findElement(By.xpath(UiMap.illustration)).click();
		
		}
		else if(AvailPdt.equals("PeakLife (LSW)") && comparison.equals("Indexed Universal Life"))
		{
			radiobtnClick(UiMap.covInsutest);
		}
		
		radiobtnClick(UiMap.covIllustrationForLSWSecure);
		if(AvailPdt.equals("LSW SecurePlus Provider") && comparison.equals("Indexed Universal Life"))
		{
			//driver.findElement(By.cssSelector(UiMap.covDeathreq)).click();
		}
		
		
		driver.findElement(By.cssSelector(UiMap.covNextButton)).click();
		System.out.println("Coverage Information completd");
		Thread.sleep(1000);
	 }
	
	public void premiumInformation() throws Exception {
		try{
		System.out.println("Premium Information");
		Thread.sleep(10000);
		objWait.waitUntilElementVisible(By.cssSelector(UiMap.preInformation), 500);
		selectElement(UiMap.preMode, ExcelData.preMode);
		textInputUsingCss(UiMap.prePlanMode, ExcelData.prePlanMode);
//		textInputUsingCss(UiMap.preQuoted, ExcelData.preQuoted);
		selectElement(UiMap.preSource, ExcelData.preSource);
		radiobtnClick(UiMap.preCashWithAppln);
		radiobtnClick(UiMap.preCashOnDelivery);
		driver.findElement(By.cssSelector(UiMap.preNext)).click();
		}
		catch (Exception ex) {
			errorMessage = "Error occured in Premium Information page";
			throw new Exception();
		}
		
	}
	
	public void interestCrediting() throws Exception {
		try {
			System.out.println("Interest Crediting");
			objWait.waitUntilElementVisible(By.cssSelector(UiMap.interestCredit), 100);
			textInputUsingCss(UiMap.interestFixedTerm, ExcelData.interestFixedTerm);
			textInputUsingCss(UiMap.interestFixedTerm1, ExcelData.interestFixedTerm);
			radiobtnClick(UiMap.interestSystemAllocation);
			radiobtnClick(UiMap.interestSystemAllocation1);
			driver.findElement(By.cssSelector(UiMap.interestNext)).click();
		} catch (Exception ex) {
			errorMessage = "Error occured in Interest Crediting page";
			throw new Exception();
		}

	}
	
	public void existingInsurance() throws Exception {
		try {
			Thread.sleep(10000);
			System.out.println("Existing Insurance - Primary Insured");
			objWait.waitUntilElementVisible(By.cssSelector(UiMap.existInsurance), 100);
			radiobtnClick(UiMap.existInsured);
			radiobtnClick(UiMap.existProposedInusred);
			radiobtnClick(UiMap.existLongTerm);
			radiobtnClick(UiMap.existIndividualGroup);
			driver.findElement(By.cssSelector(UiMap.existNext)).click();
		} catch (Exception ex) {
			errorMessage = "Error occured in Existing Insurance - Primary Insured page";
			throw new Exception();
		}

	}
	
	public void physicianInfo() throws Exception {
		try {
			System.out.println("Physician Information - Primary Insured");
			objWait.waitUntilElementVisible(By.cssSelector(UiMap.physicianInfo), 100);
			//radiobtnClick(UiMap.physicianType);
			clickElementUsingXpath("//span[text()='"+ExcelData.physicianType +"']");
			if(ExcelData.physicianType.equals("Individual"))
			{
				textInputUsingxpath(UiMap.physicianFirstName,ExcelData.physicianFirstName);
				textInputUsingxpath(UiMap.physicianLastName,ExcelData.physicianLastName);
				textInputUsingxpath(UiMap.physicianNumAndStreet,ExcelData.physicianNumberAndStreet);
				textInputUsingxpath(UiMap.physicianCity,ExcelData.physicianCity);
				selectElementUsingXpath(UiMap.physicianState,ExcelData.physicianState); //drop down
				textInputUsingxpath(UiMap.physicianZipCode,ExcelData.physicianZipCode);
				//textInputUsingxpath(UiMap.physicianFirstName,ExcelData.physicianFirstName);
				selectElementUsingXpath(UiMap.physicianRecentLastConsulted,ExcelData.physicianReasonLastConsulted);//drp down
				textInputUsingxpath(UiMap.physicianDateLastConsulted,ExcelData.physicianDateLastConsulted);
				textInputUsingxpath(UiMap.physicianOutcome,ExcelData.physicianOutcome);
				textInputUsingxpath(UiMap.physicalExplain,"sickreason");
				
			}
			else if(ExcelData.physicianType.equals("Office/Facility"))
			{
				textInputUsingxpath(UiMap.physicianofficename,ExcelData.physicianFirstName);
				textInputUsingxpath(UiMap.physicianNumAndStreet,ExcelData.physicianNumberAndStreet);
				textInputUsingxpath(UiMap.physicianCity,ExcelData.physicianCity);
				selectElementUsingXpath(UiMap.physicianState,ExcelData.physicianState); //drop down
				textInputUsingxpath(UiMap.physicianZipCode,ExcelData.physicianZipCode);
				//textInputUsingxpath(UiMap.physicianFirstName,ExcelData.physicianFirstName);
				selectElementUsingXpath(UiMap.physicianRecentLastConsulted,ExcelData.physicianReasonLastConsulted);//drp down
				textInputUsingxpath(UiMap.physicianDateLastConsulted,ExcelData.physicianDateLastConsulted);
				textInputUsingxpath(UiMap.physicianOutcome,ExcelData.physicianOutcome);
				textInputUsingxpath(UiMap.physicalExplain,"sickreason");
				//
				
			}
			driver.findElement(By.cssSelector(UiMap.physicianNext)).click();
		} catch (Exception ex) {
			errorMessage = "Error occured inPhysician Information - Primary Insured page";
			throw new Exception();
		}
	}
	
	public void personalInfo() throws Exception {
		try {
			Thread.sleep(2000);
			System.out.println("Personal Information");
			objWait.waitUntilElementVisible(By.cssSelector(UiMap.personalInfo), 200);
			selectElement(UiMap.personalHeight, ExcelData.personalHeight);
			selectElement(UiMap.personalInch, ExcelData.personalInch);
			textInputUsingCss(UiMap.personalWeight, ExcelData.personalWeight);
		//	//div[@id='div_48']/select
			
			radiobtnClick(UiMap.personalGainOrLoss);
			
			
			//textInputUsingxpath(UiMap.personalGainOrLossxpath,ExcelData.PersonalGainOrLossvalue);
			if(ExcelData.PersonalGainOrLossvalue.equals("Yes"))
			{
				selectElement(UiMap.personalGainOrLossdropdown, ExcelData.PersonalGainOrLossDropDownvalue);
			}
			radiobtnClick(UiMap.personalFather);
			radiobtnClick(UiMap.personalMother);
			Thread.sleep(1000);
			driver.findElement(By.cssSelector(UiMap.personalNext)).click();
			Thread.sleep(1000);
		} catch (Exception ex) {
			errorMessage = "Error occured in Personal Information page";
			throw new Exception();
		}
	}
	
	public void lifeStyle() throws Exception {
		try {
			System.out.println("Life Style");
			objWait.waitUntilElementVisible(By.cssSelector(UiMap.lifeStyle), 200);
			radiobtnClick(UiMap.lifeStyleQues1);
			radiobtnClick(UiMap.lifeStyleQues2);
			radiobtnClick(UiMap.lifeStyleQues3);
			radiobtnClick(UiMap.lifeStyleQues4);
			radiobtnClick(UiMap.lifeStyleQues5);
			radiobtnClick(UiMap.lifeStyleQues6);
			radiobtnClick(UiMap.lifeStyleQues7);
			radiobtnClick(UiMap.lifeStyleQues8);
			radiobtnClick(UiMap.lifeStyleQues9);
			radiobtnClick(UiMap.lifeStyleQues10);
			radiobtnClick(UiMap.lifeStyleQues11);
			
			String comparison= newobj.Product_Type.toString();
			//EAppCaseCreation covinfopage=new EAppCaseCreation();
			
			if(comparison.equals("Indexed Universal Life")||comparison.equals("Term Insurance"))
			{
			
				radiobtnClickusingxpath1(UiMap.lifestyleque);
			}
			Thread.sleep(1000);
			//radiobtnClickusingxpath1(UiMap.lifestyleque);//Gee
			driver.findElement(By.cssSelector(UiMap.lifeStyleNext)).click();
		} catch (Exception ex) {
			errorMessage = "Error occured in Life Style page";
			throw new Exception();
		}
	}
	
	public void medicalQuestion() throws Exception {
		try {
			System.out.println("Medical Questions");
			objWait.waitUntilElementVisible(By.cssSelector(UiMap.medicalQues), 200);
			radiobtnClick(UiMap.medicalQues1);
			radiobtnClick(UiMap.medicalQues2);
			radiobtnClick(UiMap.medicalQues3);
			radiobtnClick(UiMap.medicalQues4);
			radiobtnClick(UiMap.medicalQues5);
			radiobtnClick(UiMap.medicalQues6);
			radiobtnClick(UiMap.medicalQues7);
			radiobtnClick(UiMap.medicalQues8);
			radiobtnClick(UiMap.medicalQues9);
			radiobtnClick(UiMap.medicalQues10);
			radiobtnClick(UiMap.medicalQues11);
			radiobtnClick(UiMap.medicalQues12);
			radiobtnClick(UiMap.medicalQues13);
			radiobtnClick(UiMap.medicalQues14);
			radiobtnClick(UiMap.medicalQues15);
			radiobtnClick(UiMap.medicalQues16);
			radiobtnClick(UiMap.medicalQues17);
			radiobtnClick(UiMap.medicalQues18);
			radiobtnClick(UiMap.medicalQues19);
			radiobtnClick(UiMap.medicalQues20);
			radiobtnClick(UiMap.medicalQues21);
			radiobtnClick(UiMap.medicalQues22);
			radiobtnClick(UiMap.medicalQues23);
			radiobtnClick(UiMap.medicalQues24);
			radiobtnClick(UiMap.medicalQues25);
			
			
			String comparison= newobj.Product_Type.toString();
			//EAppCaseCreation covinfopage=new EAppCaseCreation();
			
			if(comparison.equals("Indexed Universal Life")|| comparison.equals("Term Insurance"))
			{
			
				radiobtnClickusingxpath1(UiMap.medque);
			}
			//radiobtnClickusingxpath1(UiMap.medque);//Gee for Indexed Universal Pdt
			driver.findElement(By.cssSelector(UiMap.medicalNext)).click();
		} catch (Exception ex) {
			errorMessage = "Error occured in Medical Questions page";
			throw new Exception();
		}
	}
	
	public void chronicQuestion() throws Exception {
		try {
		System.out.println("Chronic Questions");
		objWait.waitUntilElementVisible(By.cssSelector(UiMap.chronic), 200);
		radiobtnClick(UiMap.chronicQues1);
		radiobtnClick(UiMap.chronicQues2);
		radiobtnClick(UiMap.chronicQues3);
		radiobtnClick(UiMap.chronicQues4);
		radiobtnClick(UiMap.chronicQues5);
		radiobtnClick(UiMap.chronicQues6);
		radiobtnClick(UiMap.chronicQues7);
		radiobtnClick(UiMap.chronicQues8);
		radiobtnClick(UiMap.chronicQues9);
		radiobtnClick(UiMap.chronicQues10);
		radiobtnClick(UiMap.chronicQues12);
		radiobtnClick(UiMap.chronicQues13);
		radiobtnClick(UiMap.chronicQues14);
		radiobtnClick(UiMap.chronicQues15);
		radiobtnClick(UiMap.chronicQues16);
		radiobtnClick(UiMap.chronicQues17);
		radiobtnClick(UiMap.chronicQues18);
		radiobtnClick(UiMap.chronicQues19);
		radiobtnClick(UiMap.chronicQues20);
		radiobtnClick(UiMap.chronicQues21);
		radiobtnClick(UiMap.chronicQues22);
		radiobtnClick(UiMap.chronicQues23);
		radiobtnClick(UiMap.chronicQues24);
		radiobtnClick(UiMap.chronicQues25);
		radiobtnClick(UiMap.chronicQues26);
		radiobtnClick(UiMap.chronicQues27);
		radiobtnClick(UiMap.chronicQues28);
		radiobtnClick(UiMap.chronicQues29);
		radiobtnClick(UiMap.chronicQues30);
		radiobtnClick(UiMap.chronicQues31);
		radiobtnClick(UiMap.chronicQues32);
		driver.findElement(By.cssSelector(UiMap.chronicNext)).click();
		}  catch (Exception ex) {
			errorMessage = "Error occured in Chronic Questions page";
			//throw new Exception();
		}
	}
	
	public void noticeAndConsent() throws Exception {
		try {
			System.out.println("Notice and Consent");
			objWait.waitUntilElementVisible(By.cssSelector(UiMap.noticeConsent), 200);
			driver.findElement(By.cssSelector(UiMap.noticeNext)).click();
		} catch (Exception ex) {
			errorMessage = "Error occured in CNotice and Consent page";
			//throw new Exception();
		}
	}

	public void agentReport() throws Exception {
		try {
			System.out.println("Agent Report");
			objWait.waitUntilElementVisible(By.cssSelector(UiMap.agentReport), 200);
			radiobtnClick(UiMap.agentApplnCompleted);
			textInputUsingCss(UiMap.agentKnown, ExcelData.agentKnown);
		
			radiobtnClick(UiMap.agentRelated);
			textInputUsingCss(UiMap.agentPurpose, ExcelData.agentPurpose);
			textInputUsingCss(UiMap.agentFaceAmtDetermine, ExcelData.agentFaceAmtDetermine);
			textInputUsingCss(UiMap.agentAdditionalInfm, ExcelData.agentAdditionalInfm);
			selectElement(UiMap.agentRateClass, ExcelData.agentRateClass);
			selectElement(UiMap.agentUnderReq, ExcelData.agentUnderReq);
			driver.findElement(By.cssSelector(UiMap.agentNext)).click();
		} catch (Exception ex) {
			errorMessage = "Error occured in Agent Report page";
			//throw new Exception();
		}

	}
	
	public void agentReportCont() throws Exception {
		try {
			System.out.println("Agent Report Cont");
			objWait.waitUntilElementVisible(By.cssSelector(UiMap.agentCont), 200);
			radiobtnClick(UiMap.agentContAnyContracts);
			radiobtnClick(UiMap.agentContReplaceContracts);
			//radiobtnClick(UiMap.agentContSalesMat);
			driver.findElement(By.xpath("//*[@id='cb_69']")).click();//Gee
			radiobtnClick(UiMap.agentContPolicies1);
			radiobtnClick(UiMap.agentContPolicies2);
			radiobtnClick(UiMap.agentContPolicies3);
			radiobtnClick(UiMap.agentContPolicies4);
			selectElement(UiMap.agentContProof, ExcelData.agentIDProof);
			driver.findElement(By.cssSelector(UiMap.agentContNext)).click();
		} catch (Exception ex) {
			errorMessage = "Error occured in Agent Report Cont page";
			//throw new Exception();
		}

	}
	
	public void agentReportInf() throws Exception {
		try {
			Thread.sleep(1000);
		System.out.println("Agent Information");
		objWait.waitUntilElementVisible(By.cssSelector(UiMap.agentInfo), 200);
		//textInputUsingCss(UiMap.agentInfoFName, ExcelData.agentFirst);
		//textInputUsingCss(UiMap.agentInfoLName, ExcelData.agentLast);
		selectElement(UiMap.agentInfoNumber, ExcelData.agentNumber);
		textInputUsingCss(UiMap.agentInfoOther, ExcelData.agencyNumber);
		textInputUsingCss(UiMap.agentInfoCompensation, ExcelData.agentComp);		
		radiobtnClick(UiMap.agentInfoAdditionalAgents);
		Thread.sleep(1000);
		driver.findElement(By.cssSelector(UiMap.agentInfoAdd)).click();
		// Store your parent window
		String parentWindowHandler = driver.getWindowHandle();
		System.out.println("Parent " +parentWindowHandler);
		String subWindowHandler = null;
		// get all window handles
		Set<String> handles = driver.getWindowHandles(); 
		Iterator<String> iterator = handles.iterator();
		while (iterator.hasNext()){
		    subWindowHandler = iterator.next();
		}
		driver.switchTo().window(subWindowHandler);
		driver.switchTo().frame(driver.findElement(By.cssSelector("iframe#modalIframe")));	
		Thread.sleep(10000);
		
		textInputUsingCss(UiMap.agentSplitName, ExcelData.spAgentName);
		textInputUsingCss(UiMap.agentSplitPNum, ExcelData.spAgentPH);
		selectElement(UiMap.agentSplitANum, ExcelData.spAgentNumDD);
		textInputUsingCss(UiMap.agentSplitAgentNum, ExcelData.spAgentNum);
		textInputUsingCss(UiMap.agentSplitCompensation, ExcelData.spAgentComp);
		Thread.sleep(1000);
		driver.switchTo().defaultContent();
		driver.findElement(By.cssSelector(UiMap.agentSplitSave)).click();
		driver.switchTo().window(parentWindowHandler);
		driver.switchTo().frame(driver.findElement(By.cssSelector("iframe#CossScreenFrame.preview-runtime__iframe")));
		Thread.sleep(10000);
		
		driver.findElement(By.cssSelector(UiMap.agentInfoNext)).click();	
		} catch (Exception ex) {
			errorMessage = "Error occured in Agent Information page";
			throw new Exception();
		}
	}
	
	public void attachments() throws Exception {
		try {
			Thread.sleep(10000);
			System.out.println("Attchments");
			objWait.waitUntilElementVisible(By.cssSelector(UiMap.attachments), 200);
			driver.findElement(By.cssSelector(UiMap.attachmentsNext)).click();
		} 
		catch (Exception ex) 
		{
			errorMessage = "Error occured in Attchments page";
			throw new Exception();
		}
	}
	
	public void validatelock() throws Exception {
		try {
			System.out.println("Validate & Lock Data");
			Thread.sleep(1000);
			objWait.waitUntilElementVisible(By.cssSelector(UiMap.validate), 200);
			driver.findElement(By.xpath(UiMap.WbBtn_AddPaperWrk)).click();
			try {
				objWait.waitUntilElementVisible(By.xpath(UiMap.Wbtxt_TransId), 1000);
			} catch (Exception ex) {
				driver.navigate().refresh();
			}
			String TransText = driver.findElement(By.xpath(UiMap.Wbtxt_TransId)).getText();
			System.out.println(TransText);
			objWait.waitFor(2);
			ExcelData.TransId = TransText.substring(18, 26);
			System.out.println("Transaction ID:" + ExcelData.TransId);
			// WriteData.writeResult(UiMap.testDataSheet, testCaseName,
			// "TransactionID", ExcelData.TransId);

			driver.findElement(By.cssSelector(UiMap.lockedNext)).click();
			Thread.sleep(1000);
		} catch (Exception ex) {
			errorMessage = "Error occured in Validate & Lock Data page";
			throw new Exception();
		}
	}
	
	public void agntInst() throws Exception {
		try {
			System.out.println("Agent Instructions");
			objWait.waitUntilElementVisible(By.cssSelector(UiMap.agentIns), 200);
			driver.findElement(By.cssSelector(UiMap.WbBtn_AgentInsNext)).click();
			Thread.sleep(1000);
		} catch (Exception ex) {
			errorMessage = "Error occured in Agent Instructions page";
			throw new Exception();
		}
	}
	
	public void signMeth() throws Exception {
		try {
		System.out.println("Signature Method");
		Thread.sleep(1000);
		objWait.waitUntilElementVisible(By.cssSelector(UiMap.signMethod), 200);
		driver.findElement(By.cssSelector(UiMap.electSign)).click();	
		radiobtnClick(UiMap.electSignf2f);		
		driver.findElement(By.cssSelector(UiMap.signMethNext)).click();	
		Thread.sleep(1000);
		} catch (Exception ex) {
			errorMessage = "Error occured in Signature Method page";
			throw new Exception();
		}
	}
	
	public void esigDis() throws Exception {
		try {
			Thread.sleep(1000);
			System.out.println("eSign Disclosure");
			objWait.waitUntilElementVisible(By.cssSelector(UiMap.esigDis), 200);
			radiobtnClick(UiMap.propIns);
			driver.findElement(By.cssSelector(UiMap.esigDisNext)).click();
			Thread.sleep(1000);
		} catch (Exception ex) {
			errorMessage = "Error occured in eSign Disclosure page";
			throw new Exception();
		}
	}
	
	public void termsUse() throws Exception {
		try { 
		System.out.println("Terms of Use and eSignature Consent");
		objWait.waitUntilElementVisible(By.cssSelector(UiMap.termsUse), 200);	
		driver.findElement(By.cssSelector(UiMap.revAppPack)).click();	
		objWait.waitFor(4);
//Thread.sleep(1000);
		
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_ALT);
		robot.keyPress(KeyEvent.VK_F4);
		robot.keyPress(KeyEvent.VK_ALT);
		robot.keyPress(KeyEvent.VK_F4);
		driver.findElement(By.cssSelector(UiMap.revBuyGuid)).click();
		objWait.waitFor(2);
		
		robot.keyPress(KeyEvent.VK_ALT);
		robot.keyPress(KeyEvent.VK_F4);
		robot.keyPress(KeyEvent.VK_ALT);
		robot.keyPress(KeyEvent.VK_F4);
		
		objWait.waitUntilElementVisible(By.cssSelector(UiMap.termsUse), 200);
		objWait.waitFor(2);
		driver.findElement(By.cssSelector(UiMap.propInsCB)).click();
		driver.findElement(By.cssSelector(UiMap.agentCB)).click();
		objWait.waitFor(2);
		driver.findElement(By.cssSelector(UiMap.termUseNext)).click();	
		objWait.waitFor(3);
		} 
		catch (Exception ex)
		{
			errorMessage = "Error occured in Terms of Use and eSignature Consent page";
			ex.printStackTrace();
			//throw new Exception();
		}
	}
	
	public void eSign() throws InterruptedException, AWTException {
		Thread.sleep(1000);
		System.out.println("eSignature - Insureds/Owner/Payor/Agent");
		objWait.waitUntilElementVisible(By.cssSelector(UiMap.eSignlbl), 200);	
		driver.findElement(By.cssSelector(UiMap.pIeSign)).click();	
		driver.findElement(By.cssSelector(UiMap.ageSign)).click();
		objWait.waitFor(5);
		driver.findElement(By.cssSelector(UiMap.applyeSign)).click();
		objWait.waitFor(5);
		driver.findElement(By.cssSelector(UiMap.sendtoNLG)).click();	
		Thread.sleep(2000);
	}
	///================================End - CAse Creation method implementation till above===========================
	
	//===================Start - Sending/Selecting data to Drop Down,Radio button, Text box . Null chek, Assert
	public void textInputUsingCss(String cssPath, String value)
	{
		if(null != value && value.length() >0){
			if(reuse.IsElementExistUsingCss(driver, cssPath)) {
		driver.findElement(By.cssSelector(cssPath)).clear();	
		driver.findElement(By.cssSelector(cssPath)).sendKeys(value);
			}
		}
	}
	
	public void textInputUsingxpath(String xPath, String value)//Not sure if its working or not
	{
		if(null != value && value.length() >0){
			//if(reuse.IsElementExist(driver, xPath))
			//{
		driver.findElement(By.xpath(xPath)).clear();	
		driver.findElement(By.xpath(xPath)).sendKeys(value);
			//}
		}
	}
	
	public void clickElementUsingXpath(String xPathval)
	{
		driver.findElement(By.xpath(xPathval)).click();
	}
	
	public void selectElement(String cssPath, String value)
	{
		
		if(null != value && value.length() >0){
	//	if(reuse.IsElementExist(driver, Xpathval)){
		objWait.selectListItem(By.cssSelector(cssPath), value.trim());	
		
		//}
		}
	}
	
	public void selectElementUsingXpath(String xPath, String value)
	{
		
		if(null != value && value.length() >0){
	//	if(reuse.IsElementExist(driver, Xpathval)){
		objWait.selectListItem(By.xpath(xPath), value.trim());	
		
		//}
		}
	}
	
	public void selectCheckboxUsinfXpath(String xPathval,String value)
	{	
		if((Assert.isNonEmpty(value))){
		if(reuse.IsElementExist(driver, xPathval)){
			if(value.equalsIgnoreCase("Yes"))
			{
			if ( !driver.findElement(By.xpath(xPathval)).isSelected())
			{
			     driver.findElement(By.xpath(xPathval)).click();
			}
			}
			else
			{
				if (driver.findElement(By.xpath(xPathval)).isSelected() )
				{
				    driver.findElement(By.xpath(xPathval)).click();
				}
			}

		}
		}
	}
	public void radiobtnClick(String cssPath)
	{
		/*objWait.waitFor(5);
		if(Assert.isNonEmpty(field)){
		if(reuse.IsElementExist(driver, cssPath)){*/
		if(reuse.IsElementExistUsingCss(driver, cssPath)) {
			driver.findElement(By.cssSelector(cssPath)).click();
		}
		//}
		//}
	}
	
	public void radiobtnClickusingxpath1(String xpath)
	{
		/*objWait.waitFor(5);
		if(Assert.isNonEmpty(field)){
		if(reuse.IsElementExist(driver, cssPath)){*/
		
			driver.findElement(By.xpath(xpath)).click();
		
		//}
		//}
	}
	
	public void dateFieldCssPath(String dateCsspath, String dateValue)
	{	
		if(null != dateValue && dateValue.length() > 0){		
		String[] dateval = dateValue.split("/");
		WebElement dateField = driver.findElement(By.cssSelector(dateCsspath));
		dateField.findElement(By.cssSelector(".jq-dte-day.hint")).sendKeys(dateval[1]);
		dateField.findElement(By.cssSelector(".jq-dte-month.hint")).sendKeys(dateval[0]);
		
		dateField.findElement(By.cssSelector(".jq-dte-year.hint")).sendKeys(dateval[2]);

		}
	}
	
	public void dateFieldXPath(String dateXpath, String dateValue)
	{	
		if(Assert.isNonEmpty(dateValue)){
		if(reuse.IsElementExist(driver, dateXpath)){
		String[] Dateval = dateValue.split("/");
		driver.findElement(By.xpath("//*[@id='"+ dateXpath +"']/div/span/span[1]/input[1]")).sendKeys(Dateval[0]);
		driver.findElement(By.xpath("//*[@id='"+ dateXpath +"']/div/span/span[1]/input[2]")).sendKeys(Dateval[1]);
		driver.findElement(By.xpath("//*[@id='"+ dateXpath +"']/div/span/span[1]/input[3]")).sendKeys(Dateval[2]);	
		}
		}
	}
	
	public String nullchk(String[] Val,int iteration)
	{
		if(Assert.isNonEmpty(Val))
		{
			return Val[iteration];
		}
		else
		{
			return "";
		}
	}
	
	public void WebSelect(String Xpathval, String Value)
	{
		
		if((Assert.isNonEmpty(Value))){
		if(reuse.IsElementExist(driver, Xpathval)){
		objWait.selectListItem(By.xpath(Xpathval), Value.trim());	
		}
		}
	}
	
	
	

}
	


