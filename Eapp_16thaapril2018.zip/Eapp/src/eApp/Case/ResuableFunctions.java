package eApp.Case;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.apache.commons.io.filefilter.WildcardFileFilter;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.Assert;

import Utilities.ExcelFunctions;
import Utilities.WebDriverUtil;

/**
 * Class Contains Reusable Functions
 * @author ha0127
 */
public class ResuableFunctions {
	ExcelFunctions readData = new ExcelFunctions();
	
	
	 /**
	  * This method will write the Result in excel sheet.
	  * @param TestcaseNumber
	  * @param Status - pass or fail
	  * @param Reason - Reason for Fail (if any)
	  */
	 public void Write_Test_Result(String TestcaseNumber, String Status, String Reason)
	 {
		 if(Status.equalsIgnoreCase("Pass"))
		 {
			 readData.writeResult("Test Result", TestcaseNumber , "Status", "Pass"); 
			 readData.writeResult("Test Result", TestcaseNumber , "Remarks", "");
		 }else if(Status.equalsIgnoreCase("Fail")){
			 readData.writeResult("Test Result", TestcaseNumber , "Status", "Fail"); 
			 readData.writeResult("Test Result", TestcaseNumber , "Remarks", Reason);
		 }else
		 {
			 System.err.println("unknown Result Type.......");
		 }
		 
	 }
	 
	 /**
	  * Method will find the latest file in the path with given file Name
	  * @param filePath - Folder path 
	  * @param ext - Extension of file 
	  * @param policyNumber - file name contains
	  * @return
	  */
	 public File getTheNewestFile(String filePath, String ext , String policyNumber) {
			File theNewestFile = null;
			File dir = new File(filePath);
			FileFilter fileFilter = new WildcardFileFilter("*." + ext);
			File[] files = dir.listFiles(fileFilter);

			if (files.length > 0) {
				/** The newest file comes first **/
				Arrays.sort(files, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
				String fileName = null;
				for(int i=0; i<files.length ; i++)
				{   //System.out.println(files.length);
					theNewestFile = files[i];
					//System.out.println(theNewestFile.getName());
					fileName = theNewestFile.getName();

					if(fileName.contains(policyNumber)){
						theNewestFile = files[i];
						break;
					}else{
						System.out.println("Checking Next File....");
					}

				}//for end

				if(fileName.contains(policyNumber)){
					System.out.println("Required File Found Sucessfully");
				}else
					System.out.println("Required File Not found.....");

			}

			return theNewestFile;
		}
		
	/**
	 * Function to Convert Number into SSN format (ex:721-21-4587 )	
	 * @param ssn
	 * @return
	 */
	 public String Format_SSN(String ssn)  
	 {
	 	String[] ssn_Array = new String[3];
	 	ssn_Array[0] = ssn.substring(0, 3);
	 	ssn_Array[1] = ssn.substring(3, 5);
	 	ssn_Array[2] = ssn.substring(5, 9);
	 	String ssn_new = ssn_Array[0]+"-"+ssn_Array[1]+"-"+ssn_Array[2];
	 	//System.out.println(ssn_new);
	 	return ssn_new;
	 }
	 
	 /**
	  * This method will remove content insde '()' from a string
	  * @param text
	  * @return
	  */
	 public String Remove_bracket(String text)
	 {	String output = null;
		try {
			String arry[] = text.split("\\(");
			output = arry[0];
				
			} catch (Exception e) {
				return output;
			}
			 
		return output;
	 }

	 /**
	  * This method will read the tags from Excel file and returns  the XML value 
	  * @param fieldName - which field name we want to retrive
	  * @param ofile - XML file path 
	  * @return- String XML value
	  * @throws IOException
	  */
	 public String[] GetXML_Tags_and_Data( File ofile, String fieldName) throws IOException
	 {
		 ReadXMLValue readxmlValue = new ReadXMLValue();
		 String tagName =  readData.getExcelData("XML_Tags", UiMap.testDataExcelPath, fieldName , "Node_Name");
		 String idName = readData.getExcelData("XML_Tags", UiMap.testDataExcelPath, fieldName , "ID_Name");
		 String subNode = readData.getExcelData("XML_Tags", UiMap.testDataExcelPath, fieldName , "SubNode");
		 String elementName =  readData.getExcelData("XML_Tags", UiMap.testDataExcelPath, fieldName , "Element_Name");
		 String[] xml_Value = readxmlValue.Get_Xml_Value(ofile,tagName , idName, subNode, elementName); 
		 //System.out.println(xml_Value);
		 if(xml_Value == null)
		 {
			System.out.println(fieldName +" XML Field Not available"); 
		 }
		 return xml_Value;
	 
	 }
	 
	 /**
	  * This method willformat the DOB from XML as (MM/DD/YYYY)
	  * @param xmlDOB
	  * @return
	  */
	 public String Format_DOB(String xmlDOB)  
	 {
		 String dobxml[] = xmlDOB.split("-");
		String  formattedDOB = dobxml[1] + "/" + dobxml[2] + "/" + dobxml[0];
	 	//System.out.println(xmlDob);
	 	return formattedDOB;
	 }
	 /**
	  * This method used to handle gender option from XML file 
	  * @param xmlGender
	  * @return
	  */
	 public String Format_Gender(String xmlGender)  
	 {
		String gender = null;; 
	 
		 if (xmlGender.equalsIgnoreCase("Male"))
		 {
			gender = "M";
		 }else if(xmlGender.equalsIgnoreCase("Female")){
			 gender = "F";
		 }
			
	 	return gender;
	 	 
	 }
	 
	 /**
	  * This method will return element disabled or not 
	  * @param driver
	  * @param by
	  * @return
	  */
	 public boolean IsElementDisabled(WebDriver driver, By by)
	 { boolean enabled = true;
	     
		if(driver.findElements(by).size() >0)
		{
			 if(driver.findElement(by).isEnabled())
				{
					 enabled = false;
				}
		}else{
			enabled = true;
		}		
		 return enabled;
	 }
	 
	 public boolean IsElementExist(WebDriver driver, String Xpathval) {
		 boolean result = true;
		    try {
		    	By by;
		    	if(Xpathval.contains("div")){
		    		by = By.xpath("//*[@id='"+ Xpathval +"']/div/span/span[1]/input[1]");	
		    	}
		    	else if(Xpathval.contains("rdo_")){		    		
		    		by = By.xpath("//*[@id='"+ Xpathval +"_2']");	
		    	}
		    	else
		    	{
		    		by = By.xpath(Xpathval);
		    	}
		        driver.findElement(by).isDisplayed();
		        Assert.assertEquals(driver.findElement(by).isEnabled(), true);
		        driver.findElement(by).click();
			    result =  true;
		    } catch (Exception e) {
		        result = false;
		    }catch (AssertionError e) {
		    	result = false;
		    }
		    return result;
		}
	 
	 public boolean IsElementExistUsingCss(WebDriver driver, String cssPath) {
		 boolean result = true;
		    try {
		    	By by;
		    	by = By.cssSelector(cssPath);
		        driver.findElement(by).isDisplayed();
		        Assert.assertEquals(driver.findElement(by).isEnabled(), true);
		        driver.findElement(by).click();
			    result =  true;
		    } catch (Exception e) {
		        result = false;
		    }catch (AssertionError e) {
		    	result = false;
		    }
		    return result;
		}
	
	/* public void browser(String browser, WebDriver driver1, WebDriverUtil objWait1)
	 {
		WebDriver  driver=driver1;
		WebDriverUtil objWait=objWait1;
		 
		if(browser.equals("Chrome"))
		{
		 
		 System.out.println("Invoking Chrome Browser...!");
			//String projectPath = System.getProperty("user.dir");
			//System.out.println("Current Project path is : " + projectPath);
			
			String chromePath = "C:\\Temp\\Workspace\\Eapp\\resources\\chromedriver_win32\\chromedriver.exe";
			System.setProperty("webdriver.chrome.driver", chromePath);

			ChromeOptions options = new ChromeOptions(); // Class to manage options specific to ChromeDriver.									

			Map<String, Object> prefs = new HashMap<String, Object>();
			prefs.put("credentials_enable_service", false);
			prefs.put("profile.password_manager_enabled", false);

			options.setExperimentalOption("prefs", prefs);
			options.addArguments("chrome.switches", "--disable-extensions");
			// To Disable any browser notifications
			options.addArguments("--disable-notifications");
			// To disable yellow strip info bar which prompts info messages
			options.addArguments("enable-automation");

			driver = new ChromeDriver(options);

			driver.manage().window().maximize();
			this.objWait = new WebDriverUtil(driver);
			objWait.waitFor(3);
		}
		if(browser.equals("IE"))
		{	
			//IE browser:
			System.out.println("Invoking IE Browser");
			String iePath = "C:\\Temp\\Workspace\\Eapp\\resources\\chromedriver_win32\\IEDriverServer.exe";
			System.setProperty("webdriver.ie.driver", iePath);
			//C:\Temp\Workspace\Eapp\resources\chromedriver_win32
			//DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
			//capabilities.setCapability(InternetExplorerDriver.NATIVE_EVENTS, false);
			//driver = new InternetExplorerDriver(capabilities);
			driver = new InternetExplorerDriver();
			 
			 
			 driver.manage().window().maximize();
				this.objWait = new WebDriverUtil(driver);
				objWait.waitFor(3);
		}
		 	
	 }*/
	 
	 
	 
}
