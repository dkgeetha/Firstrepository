package eApp.Case;



public class UiMap {
	
	//InputData  sheet name
	public static String STP_RunMangerPath		= "Run Manager.xls";
	public static String RunMangersheet			= "Smoke";
	public static String testDataExcelPath		= "resources/EappTestData.xls";
	public static String Reg_ResultsExcelpath	= "resources/Regression_TestResult.xls";
	public static String testDataSheet 			= "TestData";
	public static String addPrimaryInsuredCont 	= "PrimaryInsuredCont";
	public static String addBeneficiary 		= "Beneficiary&CovInf";
	public static String addPremiumInf			= "PremiumInf&interest";
	public static String addPhysicalInfo		= "PersonalInfo";	
	public static String addagentInfo			= "AgentReport";	
	//public static String choosephysType			= "PhysicalInfo";
	public static String choosephysType			= "TestData";


	//Frame
	public static String wbFrame				= "iframe[id='CossScreenFrame']";
	public static String WbModFrame				= "iframe[id='modalIframe']";
	//Login Screen
	public static String Wbtxt_UserID 			= "input[name=user]";
	public static String Wbtxt_UserIDXpath		="//*[@id='loginDiv']/div/form/div[1]/input";
	
	public static String Wbtxt_Password 		="input[name=password]";
	public static String Wbtxt_PasswordXpath	="//*[@id='loginDiv']/div/form/div[2]/input"; 
	public static String WbBtn_Login  			= "button[name=Submit]";
	public static String WbBtn_Login_Xpath		="//*[@id='loginDiv']/div/form/button";
	public static String WbLnk_NewCase	 		= "#newcase-button";	
	
	//UatLogin
	public static String uatUsername            = "#txtUSerName";
	public static String uatPwd                 = "#txtPasssword";
	public static String loginBtn               = "#btnLogin";
	
	//AgencyLogin
	public static String loginNational			= "a#loginHref.btn.btn-primary.btn-block";
	public static String logOff 				= "//a[contains(@href,'/logOff')]";
	public static String pUser           		= "input#Ecom_User_ID.form-control";
	public static String pPassword           	= "input#Ecom_Password.form-control";
	public static String conWebsite 			= "#ctl00_btnCntWebsite";
	public static String agencyUserId			= "#SupportingUID";
	public static String goBtn					= "#SupportButton";
	public static String imageClick             = "#lblSplashInterim";
	public static String titleId   				= "#tilesMenu1";
	public static String igoImage				= "//li[@id='tilesMenu1']/div/a";
	public static String igoLink 				= "//div[@id='BusinessTools0']/ul/li/a[text()='iGo® e-App']";
	public static String welcomeLink			= "#PageBanner1_lnkUserMenu.dropdown-toggle";
	public static String signOut				= "#lnkSignOut.ngsd-enable";
	
	
	//Case Information Screen
	public static String wbtxt_InsFirstName 	= "#txtFirstName";
	
	public static String wbtxt_InsLastName 		= "#txtLastName";
	public static String wbDate_InsuredDOB	 	= ".jq-dte";	
	public static String wbtxt_InsuredAge 		= "#txtAge";
	public static String wbBtn_Ins_Gender 		= ".//*[@id='divGEN']/div/button";
	public static String wbdw_Insured_Female 	= "//span[contains(.,'Female')]";
	public static String wbdw_Insured_Male		= "//span[contains(.,'Male')]";
	public static String wbtxt_Case_Desc 		= "#txtCaseDescription";
	public static String wbdw_Sol_State 		= "#ddlState";
	public static String wbdw_Prod_Type 		= "#ddlProductType";
	public static String wbLnk_AvlProducts		= "#btnFindAvailableProducts";
	public static String wbTbl_Prod_rows		= "//*[@id='GridView1']/tbody/tr";
	public static String wbTbl_Prod_cols		= "//*[@id='GridView1']/thead/tr";
	public static String selectState            = "//div[@id ='UpdatePanel1']/div/button/span[text()='Please select...']";
	public static String productPanel 			= "//*[@id='UpdatePanel2']";
	
	//Case Information Screen -Xpath- Geetha
	public static String webtxt_InsFirstName="//input[@id='txtFirstName']";
	
	//Pre Qualification
	public static String pre_Qual = "h1#lbl_9";
	public static String cond_Apply = "#rdo_2_2";
	public static String next="button#btn_8.btn.btn-default.btn-block.btn-primary.btn-sm ";
	
	//primaryInsured
	public static String primaryInsured ="#lbl_114";
	public static String primarySSN = "input#flda_109.form-control.input-sm.is-required";
	public static String primaryCountry = "select#lb_126.form-control.input-sm.is-required";
	public static String primaryCitizen = "span#lbl_106_1";
	public static String primaryAddress= "input#flda_8.form-control.input-sm.is-required";
	public static String primaryCity = "input#flda_115.form-control.input-sm.is-required";
	public static String primaryState = "select#lb_112.form-control.input-sm.is-required";
	public static String primaryZipcode = "input#flda_116.form-control.input-sm.is-required";
	public static String primaryPhoneToContact = "select#lb_179.form-control.input-sm";
	public static String primaryPhoneNum = "input#flda_53.form-control.input-sm";
	public static String primaryMailAddr ="input#rdo_138_2.top-aligned";
	public static String primaryOwner ="input#rdo_39_1.top-aligned";
	public static String primaryJointOwner ="input#rdo_91_2.top-aligned";
	public static String primarySecAdd ="input#rdo_157_2.top-aligned";
	public static String primaryNext ="button#btn_16.btn.btn-default.btn-block.btn-primary.btn-sm ";
	
	public static String primaryPhoneToContactForPeak = "select#lb_179.form-control.input-sm";
	public static String primaryNextxpath= "//*[@id='btn_16']";
	//select#lb_181.form-control.input-sm
	
	//Primary Insured, Cont
	public static String priCont = "#lbl_11";
	public static String priContDriverLic = "input#rdo_38_2.top-aligned";
	public static String priContEmpl = "select#lb_5.form-control.input-sm";
	public static String priContAnnIncome = "input#flda_61.form-control.input-sm";
	public static String priContNet = "input#flda_64.form-control.input-sm";
	public static String priContHouseIncome = "input#flda_59.form-control.input-sm.is-required";
	public static String priContNetHouse = "input#flda_57.form-control.input-sm.is-required";
	public static String priContInterview = "input#rdo_100_2.top-aligned";
	public static String priContCopy = "input#rdo_101_2.top-aligned";
	public static String priContreason = "select#lb_76.form-control.input-sm.is-required";
	public static String priContNext = "button#btn_7.btn.btn-default.btn-block.btn-primary.btn-sm ";
	public static String priContNextxpath="//*[@id='btn_7']/span ";
	
	//Beneficiaries - Primary Insured
	public static String benePriInsured = "#lbl_8";
	public static String benePriAdd     = "#grdx5_addRowButton.btn.btn-block.btn-primary";
	public static String beneRelation ="select#lb_78.form-control.input-sm";
	public static String beneFirstName = "input#flda_13.form-control.input-sm.is-required";
	public static String beneMiddleName = "input#flda_11.form-control.input-sm ";
	public static String beneLastName = "input#flda_17.form-control.input-sm.is-required";
	public static String beneSSN = "input#flda_19.form-control.input-sm";
	public static String beneDOB ="span.jq-dte-inner.jq-dte-is-required";
	public static String beneShare = "input#flda_4.form-control.input-sm";
	public static String beneResiAddr = "input#cb_110.top-aligned";
	public static String beneSave = "button#btn_28.btn.btn-default.btn-primary.btn-sm";
	public static String beneContBeneficiary = "input#rdo_19_2.top-aligned";
	public static String beneNext = "button#btn_17.btn.btn-default.btn-block.btn-primary.btn-sm ";
	
	
	//Coverage Information
	public static String covInform_old = "#lbl_295";
	public static String covInformFrame="iframe#CossScreenFrame.preview-runtime__iframe";
	//iframe#CossScreenFrame.preview-runtime__iframe
	//"iframe[id='modalIframe']";
	public static String covInform="h1[id=lbl_4]";
	public static String covFaceAmt_old = "input#flda_110.form-control.input-sm";
	public static String covFaceAmt="input#flda_5.form-control.input-sm";
	public static String covDeathBO = "select#lb_111.form-control.input-sm";
	public static String covInsutest = "input#rdo_113_1.top-aligned";
	public static String covDeathreq = "input#cb_265.top-aligned";
	public static String covIllustration = "input#rdo_41_1.top-aligned";
	public static String covNext = "button#btn_1.btn.btn-default.btn-block.btn-primary.btn-sm ";
	
	//coverage Information - Part2 Indexed Universal Pdt LSW SecurePlus Provider
	public static String covFaceAmount="input#flda_110.form-control.input-sm";
	public static String covNextButton="button#btn_10.btn.btn-default.btn-block.btn-primary.btn-sm";
	public static String covIllustrationForLSWSecure ="input#rdo_319_1.top-aligned";
	
	//Coverage Information -xpath
	public static String covnewxpath="//h1[text()='Coverage Information']";
	public static String cashvalue= "//*[@id='rdo_113_2']";
	public static String illustration="//*[@id='rdo_320_1']";
	public static String covInformxpath = "//div[@id='div_4']/h1";
	public static String covFaceAmtxpath= "//div[@id='div_5']/input[1]";
	
	//Premium Information
	public static String preInformation ="#lbl_81";
	public static String preMode = "select#lb_82.form-control.input-sm.is-required";
	public static String prePlanMode = "input#flda_75.form-control.input-sm.is-required";
	public static String preQuoted = "input#flda_9.form-control.input-sm.is-required";
	public static String preSource = "select#lb_150.form-control.input-sm";
	public static String preCashWithAppln = "input#rdo_56_2.top-aligned";
	public static String preCashOnDelivery = "input#rdo_7_1.top-aligned";
	public static String preNext ="button#btn_101.btn.btn-default.btn-block.btn-primary.btn-sm ";
	
	//Interest Crediting
	public static String interestCredit ="#lbl_20";
	public static String interestFixedTerm ="input#flda_30.form-control.input-sm";
	public static String interestSystemAllocation = "input#rdo_41_2.top-aligned";
	public static String interestFixedTerm1 ="input#flda_13.form-control.input-sm";
	public static String interestSystemAllocation1 = "input#rdo_39_2.top-aligned";
	public static String interestNext = "button#btn_2.btn.btn-default.btn-block.btn-primary.btn-sm ";
	
	
	//Existing Insurance - Primary Insured
	public static String existInsurance = "#lbl_62";
	public static String existInsured = "input#rdo_1_2.top-aligned";
	public static String existProposedInusred ="input#rdo_66_2.top-aligned";
	public static String existLongTerm ="input#rdo_76_2.top-aligned";
	public static String existIndividualGroup ="input#rdo_122_2.top-aligned";
	public static String existNext = "button#btn_68.btn.btn-default.btn-block.btn-primary.btn-sm ";
	
	//Physician Information - Primary Insured
	public static String physicianInfo ="#lbl_55";
	public static String physicianType ="input#rdo_2_3.top-aligned";
	public static String physicianNext ="button#btn_29.btn.btn-default.btn-block.btn-primary.btn-sm ";
	
	//Physician Information - Primary Insured-xpath
	public static String physicianFirstName="//div[@id='div_10']/input";
	public static String physicianLastName="//div[@id='div_8']/input"; 
	public static String physicianNumAndStreet="//div[@id='div_20']/input";
	public static String physicianCity="//div[@id='div_19']/input";
	public static String physicianState="//div[@id='div_24']/select"; 
	public static String physicianZipCode="//div[@id='div_18']/input[1]";
	public static String physicianRecentLastConsulted="//div[@id='div_45']/select";
	public static String physicianDateLastConsulted="//div[@id='div_52']/input[1]";
	public static String physicianOutcome="//div[@id='div_42']/textarea";
	public static String physicianofficename="//div[@id='div_16']/input";
	public static String physicalExplain="//*[@id='flda_51']";
	
	
	//Personal Information
	public static String personalInfo ="#lbl_22";
	public static String personalHeight = "select#lb_20.form-control.input-sm";
	public static String personalInch = "select#lb_18.form-control.input-sm";
	public static String personalWeight = "input#flda_15.form-control.input-sm";
	public static String personalGainOrLoss = "input#rdo_55_2.top-aligned";
	public static String personalFather ="input#rdo_4_2.top-aligned";
	public static String personalMother ="input#rdo_33_2.top-aligned";
	public static String personalNext = "button#btn_40.btn.btn-default.btn-block.btn-primary.btn-sm ";
	
	////Personal Information - xpath
	public static String personalGainOrLossxpath="//div[@id='div_55']/div[2]/label[1]/div/span[text()='"+ExcelData.PersonalGainOrLossvalue +"']";
	
	public static String personalGainOrLossxpathForNo="//div[@id='div_55']/div[2]/label[2]/div/span[text()='"+ExcelData.PersonalGainOrLossvalue +"']";
	public static String personalGainOrLossdropdown="//div[@id='div_55']/div[2]/label[1]/div/span[text()='"+ExcelData.PersonalGainOrLossDropDownvalue +"']";
	
	//LifeStyleQuestion
	public static String lifeStyle = "#lbl_8";
	public static String lifeStyleQues1 = "input#rdo_35_2.top-aligned";
	public static String lifeStyleQues2 = "input#rdo_11_2.top-aligned";
	public static String lifeStyleQues3 = "input#rdo_51_2.top-aligned";
	public static String lifeStyleQues4 = "input#rdo_21_2.top-aligned";
	public static String lifeStyleQues5 = "input#rdo_37_2.top-aligned";
	public static String lifeStyleQues6 = "input#rdo_14_2.top-aligned";
	public static String lifeStyleQues7 = "input#rdo_54_2.top-aligned";
	public static String lifeStyleQues8 = "input#rdo_56_2.top-aligned";
	public static String lifeStyleQues9 = "input#rdo_18_2.top-aligned";
	public static String lifeStyleQues10 = "input#rdo_38_2.top-aligned";
	public static String lifeStyleQues11 = "input#rdo_111_2.top-aligned";
	public static String lifeStyleNext = "button#btn_33.btn.btn-default.btn-block.btn-primary.btn-sm ";
	
	//LifeStyleQuestion
	public static String lifestyleque= "//*[@id='rdo_16_2']";
	
	//Medical Questions
	public static String medicalQues = "#lbl_162";
	public static String medicalQues1 = "input#rdo_35_2.top-aligned" ;
	public static String medicalQues2 = "input#rdo_9_2.top-aligned" ;
	public static String medicalQues3 = "input#rdo_11_2.top-aligned" ;
	public static String medicalQues4 = "input#rdo_36_2.top-aligned" ;
	public static String medicalQues5 = "input#rdo_21_2.top-aligned" ;
	public static String medicalQues6 = "input#rdo_37_2.top-aligned" ;
	public static String medicalQues7 = "input#rdo_5_2.top-aligned" ;
	public static String medicalQues8 = "input#rdo_14_2.top-aligned" ;
	public static String medicalQues9 = "input#rdo_16_2.top-aligned" ;
	public static String medicalQues10 = "input#rdo_71_2.top-aligned" ;
	public static String medicalQues11 = "input#rdo_18_2.top-aligned" ;
	public static String medicalQues12 = "input#rdo_38_2.top-aligned" ;
	public static String medicalQues13 = "input#rdo_24_2.top-aligned" ;
	public static String medicalQues14 = "input#rdo_44_2.top-aligned" ;
	public static String medicalQues15 = "input#rdo_47_2.top-aligned" ;
	public static String medicalQues16 = "input#rdo_75_2.top-aligned" ;
	public static String medicalQues17 = "input#rdo_78_2.top-aligned" ;
	public static String medicalQues18 = "input#rdo_83_2.top-aligned" ;
	public static String medicalQues19 = "input#rdo_87_2.top-aligned" ;
	public static String medicalQues20 = "input#rdo_90_2.top-aligned" ;
	public static String medicalQues21 = "input#rdo_97_2.top-aligned" ;
	public static String medicalQues22 = "input#rdo_99_2.top-aligned" ;
	public static String medicalQues23 = "input#rdo_102_2.top-aligned" ;
	public static String medicalQues24 = "input#rdo_59_2.top-aligned" ;
	public static String medicalQues25 = "input#rdo_50_2.top-aligned" ;
	public static String medicalNext = "button#btn_33.btn.btn-default.btn-block.btn-primary.btn-sm ";
	
	//Medical Questions
	public static String medque="//*[@id='rdo_129_2']";
	
	//Chronic Care Medical - Primary Insured
	public static String chronic = "#lbl_16";
	public static String chronicQues1 ="input#rdo_71_2.top-aligned";
	public static String chronicQues2 ="input#rdo_72_2.top-aligned";
	public static String chronicQues3 ="input#rdo_73_2.top-aligned";
	public static String chronicQues4 ="input#rdo_74_2.top-aligned";
	public static String chronicQues5 ="input#rdo_75_2.top-aligned";
	public static String chronicQues6 ="input#rdo_76_2.top-aligned";
	public static String chronicQues7 ="input#rdo_77_2.top-aligned";
	public static String chronicQues8 ="input#rdo_78_2.top-aligned";
	public static String chronicQues9 ="input#rdo_80_2.top-aligned";
	public static String chronicQues10 ="input#rdo_81_2.top-aligned";
	public static String chronicQues12 ="input#rdo_82_2.top-aligned";
	public static String chronicQues13 ="input#rdo_83_2.top-aligned";
	public static String chronicQues14 ="input#rdo_84_2.top-aligned";
	public static String chronicQues15 ="input#rdo_89_2.top-aligned";
	public static String chronicQues16 ="input#rdo_90_2.top-aligned";
	public static String chronicQues17 ="input#rdo_91_2.top-aligned";
	public static String chronicQues18 ="input#rdo_92_2.top-aligned";
	public static String chronicQues19 ="input#rdo_93_2.top-aligned";
	public static String chronicQues20 ="input#rdo_94_2.top-aligned";
	public static String chronicQues21 ="input#rdo_95_2.top-aligned";
	public static String chronicQues22 ="input#rdo_96_2.top-aligned";
	public static String chronicQues23 ="input#rdo_97_2.top-aligned";
	public static String chronicQues24 ="input#rdo_98_2.top-aligned";
	public static String chronicQues25 ="input#rdo_99_2.top-aligned";
	public static String chronicQues26 ="input#rdo_101_2.top-aligned";
	public static String chronicQues27 ="input#rdo_100_2.top-aligned";
	public static String chronicQues28 ="input#rdo_102_2.top-aligned";
	public static String chronicQues29 ="input#rdo_104_2.top-aligned";
	public static String chronicQues30 ="input#rdo_103_2.top-aligned";
	public static String chronicQues31 ="input#rdo_65_2.top-aligned";
	public static String chronicQues32 ="input#rdo_64_2.top-aligned";
	public static String chronicNext = "button#btn_105.btn.btn-default.btn-block.btn-primary.btn-sm ";
	
	//Notice and Consent - Primary Insured
	public static String noticeConsent = "#lbl_5";
	public static String noticeNext ="button#btn_4.btn.btn-default.btn-block.btn-primary.btn-sm ";
	
	//Agent Report
	public static String agentReport ="#lbl_4";
	public static String agentApplnCompleted = "input#rdo_34_1.top-aligned";
	public static String agentKnown = "input#flda_2.form-control.input-sm";
	public static String agentRelated = "input#rdo_9_2.top-aligned";
	public static String agentPurpose = "input#flda_81.form-control.input-sm";
	public static String agentFaceAmtDetermine = "input#flda_85.form-control.input-sm";
	public static String agentAdditionalInfm = "textarea#flda_80.form-control.input-sm";
	public static String agentRateClass = "select#lb_57.form-control.input-sm";
	public static String agentUnderReq = "select#lb_101.form-control.input-sm";
	public static String agentNext = "button#btn_5.btn.btn-default.btn-block.btn-primary.btn-sm ";
	
	//Agent Report, Cont
	public static String agentCont = "#lbl_97";
	public static String agentContAnyContracts = "input#rdo_49_2.top-aligned";
	public static String agentContReplaceContracts = "input#rdo_31_2.top-aligned";
	public static String agentContSalesMat = "input#cb_69.top-aligned";
	public static String agentContPolicies1 = "input#rdo_9_2.top-aligned";
	public static String agentContPolicies2 = "input#rdo_37_2.top-aligned";
	public static String agentContPolicies3 = "input#rdo_35_2.top-aligned";
	public static String agentContPolicies4 = "input#rdo_39_2.top-aligned";
	public static String agentContProof = "select#lb_59.form-control.input-sm";
	public static String agentContNext = "button#btn_5.btn.btn-default.btn-block.btn-primary.btn-sm ";
	
	//Agent Information
	public static String agentInfo ="#lbl_30";
	public static String agentInfoFName = "input#flda_28.form-control.input-sm";
	public static String agentInfoLName = "input#flda_46.form-control.input-sm";
	public static String agentInfoNumber = "select#lb_50.form-control.input-sm";
	public static String agentInfoOther = "input#flda_82.form-control.input-sm";
	public static String agentInfoCompensation = "input#flda_19.form-control.input-sm";
	public static String agentInfoAdditionalAgents = "input#rdo_5_1.top-aligned";
	public static String agentInfoAdd = "button#grdx15_addRowButton.btn.btn-block.btn-primary";
	public static String agentSplitName = "input#flda_2.form-control.input-sm.is-required";
	public static String agentSplitPNum = "input#flda_17.form-control.input-sm.is-required";
	public static String agentSplitANum ="select#lb_28.form-control.input-sm";
	public static String agentSplitSuffix = "input#flda_38.form-control.input-sm";
	public static String agentSplitAgentNum = "input#flda_29.form-control.input-sm";
	public static String agentSplitCompensation = "input#flda_9.form-control.input-sm";
	public static String agentSplitSave = "button#btn_6.btn.btn-default.btn-primary.btn-sm";
	public static String agentInfoNext = "button#btn_31.btn.btn-default.btn-block.btn-primary.btn-sm ";
	
	//Attachments
	public static String attachments = "#lbl_2";
	public static String attachmentsNext = "button#btn_24.btn.btn-default.btn-block.btn-primary.btn-sm ";
	
	//Validate Data
	public static String validate = "#lbl_12";
	public static String lock = "button#btn_8.btn.btn-default.btn-primary.btn-sm";
	public static String transMsg = "#lbl_34.alert.alert-info";	
	
	//Additional Paperwork
	public static String WbBtn_AddPaperWrk		= "//*[@id='btn_8']";	
	public static String Wbtxt_TransId			= "//*[@id='lbl_34']";
	public static String lockedNext = "button#btn_49.btn.btn-default.btn-block.btn-primary.btn-sm ";
	
	
	//Agent Instructions
	public static String agentIns = "#lbl_3";
	public static String WbBtn_AgentInsNext	= "button#btn_4.btn.btn-default.btn-block.btn-primary.btn-sm ";
	
	//Signature Method
	public static String signMethod	= "#lbl_4";
	public static String electSign = "#cb_44.top-aligned"; 
	public static String electSignf2f = "#rdo_42_1.top-aligned";
	public static String signMethNext	= "button#btn_6.btn.btn-default.btn-block.btn-primary.btn-sm ";
	
	//eSignature Disclosures
	public static String esigDis		= "#lbl_16";
	public static String propIns 		= "input#rdo_24_1.top-aligned";
	public static String esigDisNext	= "button#btn_66.btn.btn-default.btn-block.btn-primary.btn-sm ";
	
	//eSignature Verifications
	public static String WbBtn_eSignVerNext		= "//*[@id='btn_33']";
	
	//Terms and Signatures
	public static String termsUse	= "h1#lbl_3";
	public static String revAppPack	= "button#btn_15.btn.btn.btn-default.btn-block.btn-sm ";
	public static String revBuyGuid	= "button#btn_56.btn.btn.btn-default.btn-block.btn-sm ";
	public static String propInsCB = "#cb_36.top-aligned";
	public static String agentCB = "#cb_35.top-aligned";
	public static String termUseNext	= "button#btn_8.btn.btn-default.btn-block.btn-primary.btn-sm ";
	
	//eSignature - Insureds/Owner/Payor/Agent
	public static String eSignlbl	= "#lbl_12";
	public static String pIeSign = "#cb_20.top-aligned";
	public static String ageSign = "#cb_39.top-aligned";
	public static String applyeSign	= "button#btn_6.btn.btn-default.btn-block.btn-primary.btn-sm ";
	public static String sendtoNLG	= "button#btn_46.btn.btn-default.btn-block.btn-primary.btn-sm ";
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
