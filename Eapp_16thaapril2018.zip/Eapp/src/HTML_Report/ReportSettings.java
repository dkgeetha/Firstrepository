package HTML_Report;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import Utilities.Utility;


public class ReportSettings {
	
Utility Util = new Utility();
public	Properties properties;

public String ReportPath, ReportName , setDateFormatString;
public static String ProjectName;
public String RelativePath;
public boolean HTML_Result;
public ReportTheme theme;
public String timeStamp;
public boolean linkTestLogsToSummary = false;
	public ReportSettings ()
	{
		Get_All_Settings();
	}
	
	
	public void Get_All_Settings()
	{
		setRelativePath();
		loadFromPropertiesFile();
		Read_Properties();
		theme = getReportsTheme(properties.getProperty("ReportsTheme"));
		
		Create_Results_Path();
		
		//System.out.println("Current Report Theme: "+properties.getProperty("ReportsTheme"));
	
		
	}
	
	
	
	
	public void Read_Properties()
	{
		ProjectName = properties.getProperty("ProjectName");
		timeStamp =
				"Run_" +
				Util.getCurrentFormattedTime(properties.getProperty("DateFormatString"))
				.replace(" ", "_").replace(":", "-"); 
		//System.out.println(ProjectName);
		ReportName = properties.getProperty("RunConfiguration");
		setDateFormatString = properties.getProperty("DateFormatString");
		HTML_Result = Boolean.parseBoolean(properties.getProperty("HtmlReport"));
		
	}
	
	public  void Create_Results_Path()
	{
		 timeStamp =
				"Run_" +
				Util.getCurrentFormattedTime(properties.getProperty("DateFormatString"))
				.replace(" ", "_").replace(":", "-"); 
		
		ReportPath =
				RelativePath +
				Util.getFileSeparator() + "Results" +
				Util.getFileSeparator() + ProjectName ;
			/*	+ 
				Util.getFileSeparator() + timeStamp;*/
        
        new File(ReportPath).mkdirs();
	}
	
	
	public void setRelativePath()
	{
		 try {
			 RelativePath = new File(System.getProperty("user.dir")).getAbsolutePath();
		} catch (Exception e) {
			System.out.println("Error While Getting Relativepath ");
			e.printStackTrace();
		}
		
		
	}
	
	
	private  void loadFromPropertiesFile()
	{
			properties = new Properties();
			String projectPath=System.getProperty("user.dir");
		try {
			properties.load(new FileInputStream( projectPath+
									Util.getFileSeparator() + "Global Settings.properties"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.out.println("FileNotFoundException while loading the Global Settings file");
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("IOException while loading the Global Settings file");
		}
		
		
	}
	
	/*public enum Theme
	{
		CLASSIC, MYSTIC, AUTUMN, OLIVE, REBEL, RETRO, SERENE
	}
	
	*/
		/**
		 * Function to return the {@link ReportTheme} object based on the color {@link Theme} specified
		 * @param theme The color {@link Theme} to be used for the report
		 * @return The {@link ReportTheme} object
		 */
		public static ReportTheme getReportsTheme(String theme)
		{
			ReportTheme reportTheme = new ReportTheme();
			
			switch (theme) {
			case "CLASSIC":
				reportTheme.setHeadingBackColor("#687C7D");
                reportTheme.setHeadingForeColor("#FFFFFF");
                reportTheme.setSectionBackColor("#8B9292");
                reportTheme.setSectionForeColor("#001429");
                reportTheme.setContentForeColor("#282A2A");
                reportTheme.setContentBackColor("#EDEEF0");

              
		/*		reportTheme.setHeadingBackColor("#495758");
				reportTheme.setHeadingForeColor("#95A3A4");
				reportTheme.setSectionBackColor("#8B9292");
				reportTheme.setSectionForeColor("#001429");
				reportTheme.setContentForeColor("#282A2A");
				reportTheme.setContentBackColor("#EDEEF0");*/
				
				break;
				
			case "MYSTIC":
				reportTheme.setHeadingBackColor("#4D7C7B");
				reportTheme.setHeadingForeColor("#FFFF95");
				reportTheme.setSectionBackColor("#89B6B5");
				reportTheme.setSectionForeColor("#333300");
				reportTheme.setContentBackColor("#FAFAC5");
				reportTheme.setContentForeColor("#000000");
				break;
				
			case "AUTUMN":
				reportTheme.setHeadingBackColor("#9933FF");
				reportTheme.setHeadingForeColor("#FFD1FF");
				reportTheme.setSectionBackColor("#F5E6E6");
				reportTheme.setSectionForeColor("#3D001F");
				reportTheme.setContentForeColor("#8F0047");
				reportTheme.setContentBackColor("#F6F3E4");
				break;
				
			case "OLIVE":
				reportTheme.setHeadingBackColor("#86816A");
				reportTheme.setHeadingForeColor("#333300");
				reportTheme.setSectionBackColor("#A6A390");
				reportTheme.setSectionForeColor("#001F00");
				reportTheme.setContentForeColor("#003326");
				reportTheme.setContentBackColor("#E8DEBA");
				break;
				
			case "REBEL":
				reportTheme.setHeadingBackColor("#953735");
				reportTheme.setHeadingForeColor("#FFA3A3");
				reportTheme.setSectionBackColor("#CC9999");
				reportTheme.setSectionForeColor("#4D0000");
				reportTheme.setContentForeColor("#3D1F00");
				reportTheme.setContentBackColor("#D9D9D9");
				break;
				
			case "RETRO":
				reportTheme.setHeadingBackColor("#CE824E");
				reportTheme.setHeadingForeColor("#291A10");
				reportTheme.setSectionBackColor("#AA9B7C");
				reportTheme.setSectionForeColor("#3D3D29");
				reportTheme.setContentForeColor("#996600");
				reportTheme.setContentBackColor("#F8F1E7");
				break;
				
			case "SERENE":
				reportTheme.setHeadingBackColor("#CC8099");
				reportTheme.setHeadingForeColor("#470047");
				reportTheme.setSectionBackColor("#C285C2");
				reportTheme.setSectionForeColor("#3D001F");
				reportTheme.setContentForeColor("#330080");
				reportTheme.setContentBackColor("#C5AFC6");
				break;
			}
			
			return reportTheme;
		}
	
	
	
	
	
	
}	
	
	
	
	

