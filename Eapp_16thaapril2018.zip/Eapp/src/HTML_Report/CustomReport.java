package HTML_Report;


public class CustomReport {
	
	
	
public CustomReport() {
		super();
		
	}
	public CustomReport(String sprint, String scenarioId,  String testCaseDesc, Status result,
		String failReason, String imageForFail ) {
		super();
		this.scenarioId = scenarioId;
		this.testCaseDesc = testCaseDesc;
		this.result = result;
		this.failReason = failReason;
		this.imageForFail = imageForFail;
		this.sprint = sprint;
	}
	
	
	private String scenarioId;
	private String testCaseDesc;
	private Status result;
	private String failReason;
	private String imageForFail;
	private String sprint;
	
	public String getsprint() {
		return sprint;
	}
	public void setsprint(String sprint) {
		this.sprint = sprint;
	}
	
	
	
	
	public String getScenarioId() {
		return scenarioId;
	}
	public void setScenarioId(String scenarioId) {
		this.scenarioId = scenarioId;
	}
	public String getTestCaseDesc() {
		return testCaseDesc;
	}
	public void setTestCaseDesc(String testCaseDesc) {
		this.testCaseDesc = testCaseDesc;
	}
	public Status getResult() {
		return result;
	}
	public void setResult(Status result) {
		this.result = result;
	}
	public String getFailReason() {
		return failReason;
	}
	public void setFailReason(String failReason) {
		this.failReason = failReason;
	}
	public String getImageForFail() {
		return imageForFail;
	}
	public void setImageForFail(String imageForFail) {
		this.imageForFail = imageForFail;
	}
	
	
	

}
