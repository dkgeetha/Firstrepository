package HTML_Report;

import java.io.File;
import java.util.Map;

import Utilities.Utility;




public class Report_Generator {
	
	 //ReportSettings settings = new ReportSettings();
	 ReportTheme reporttheme = new ReportTheme();
	Utility Util = new Utility();
	ReportSettings settings = new ReportSettings();
	HtmlReport htmlReport;
	String startTime, endTime, resultstatus;
	Status compstatus;
	int failed, passed, total;
	
	public void Initialize_Summary(Map<Integer, CustomReport> result)
	{
		Start_Summary();
		
	   total = result.size();
		for(int i=1 ; i<=result.size() ; i++)
		{
		CustomReport test = (CustomReport)result.get(i);
		if(test.getResult().toString().equalsIgnoreCase("PASS"))
		{
			resultstatus = "PASS";
			passed= passed+1;
		}else{
			resultstatus = "FAIL";
			failed = failed+1;
		}
		
		write_summaryTable(test.getsprint(), test.getScenarioId(), test.getTestCaseDesc(), test.getFailReason(), test.getImageForFail(), resultstatus);
		
		//System.out.println(test.getFailReason());
		//System.out.println(test.getResult());	
		}
		Close_Summary();
	}
	

	private void Start_Summary()
	{
		ReportSettings settings = new ReportSettings();
		//settings.Get_All_Settings();
			new File(settings.ReportPath +
						Util.getFileSeparator() + "HTML Results").mkdir();
			
		 htmlReport = new HtmlReport(settings, settings.theme);
			htmlReport.initializeResultSummary();
		
			htmlReport.addResultSummaryHeading(ReportSettings.ProjectName +
					" - " +	" Automation Execution Result Summary");
			htmlReport.createResultSummaryHeaderTable();	
			startTime = Util.getCurrentFormattedTime("dd-MMM-yyyy hh:mm:ss a");
			htmlReport.addResultSummarySubHeading(" Date & Time :  "+startTime,"", "    ", "    ");
			htmlReport.addResultSummarySubHeading(" Run Configuration : "+ settings.ReportName,"", "   ", "  ");
			htmlReport.createResultSummaryMainTable();
			htmlReport.addResultSummaryTableHeadings();	
			
		
		
		/*new File(reportSettings.getReportPath() + Util.getFileSeparator() +
															"Screenshots").mkdir();*/
	}
	
	private void write_summaryTable(String Sprint, String TestcaseName, String TestDespcription,String Reason, String screenshotName, String  Status)
	{
		
		htmlReport.updateResultSummary(Sprint, TestcaseName, TestDespcription, Reason,  screenshotName,  Status);
		
		
	}
	
	
	private void Close_Summary()  
	{
		

		htmlReport.addResultSummaryFooter(Integer.toString(total), passed, failed);
		
		htmlReport.openReport();
				
		
	}
	
	
	
	
	/**
	 * *******************************These are comparing result HTML functions****************************************
	 */
	
	
	/* Comparing HTML Functions*/
	private int stepsfailed = 0;
	private int stepspassed = 0;
	
	/*public void initialize_compResult(Map compresult)
	{
		Start_compSummary();
		
		
		
		 int comptotal = compresult.size();
			for(int i=1 ; i<=compresult.size() ; i++)
			{
				ComparingResult test2 = (ComparingResult)compresult.get(i);
			if(test2.getResult().toString().equalsIgnoreCase("Equal"))
			{
				compstatus = Status.EQUAL;
				
				
			}else{
				compstatus = Status.DIFFERENT;
				
				
			}
			updateTestLOG(test2.getIterationNum(), test2.getFieldName(), test2.getXmlValue(), test2.getExcelValue(), compstatus);
			}		
	}
	
	*/
	/**
	 * This function will initilize the Comparing result HTML summary
	 */
	public void Start_compSummary(String environment, String policyNum)
	{
		ReportSettings settings = new ReportSettings();
		new File(settings.ReportPath +
					Util.getFileSeparator() + "XML Results").mkdir();
		 htmlReport = new HtmlReport(settings, settings.theme);
		 htmlReport.initializeTestLog();
		 htmlReport.addTestLogHeading(ReportSettings.ProjectName +
					" - " +	" Automation XML Comparision Result Summary");
		 startTime = Util.getCurrentFormattedTime("dd-MMM-yyyy hh:mm:ss a");
		 htmlReport.addTestLogSubHeading(" Date & Time :  "+startTime,"", "    ", "    ");
		 htmlReport.addTestLogSubHeading(" Current Environment :  "+environment,"", "Policy Number:", policyNum);
		 htmlReport.addTestLogTableHeadings();		
	}
	
	public  void updateTestLOG(String iteratinNum, String fieldName, String XMLvalue, String excelValue, String result)
	{
		Status status;
		if(result.equalsIgnoreCase("Equal"))
		{
			status = Status.EQUAL;
			stepspassed++;
		}else{
			status = Status.DIFFERENT;
			stepsfailed++;
		}
		htmlReport.updateTestLog(iteratinNum, fieldName, XMLvalue, excelValue, status);
	}
	
	//To update section
	public void updateSection(String section)
	{
		htmlReport.addTestLogSection(section);
	}
	
	//to Update sub section
	public void updateSubSection(String subsection)
	{
		htmlReport.addTestLogSubSection(subsection);
	}
	
	//closing comparing result summary
	public void closeCompResult()
	{
		htmlReport.addTestLogFooter(stepspassed+stepsfailed, stepspassed,stepsfailed);
		htmlReport.openComparisionReport();
		
	}
	
	
	

	
}
