package HTML_Report;

public class ComparingResult {
	
	private String fieldName;
	private String iterationNum;
	private String xmlValue;
	private String excelValue;
	private String result;
	
	
	public ComparingResult(String fieldName, String iterationNum,String xmlValue,  String excelValue, String result )
	{
		this.fieldName = fieldName;
		this.iterationNum = iterationNum;
		this.xmlValue = xmlValue;
		this.excelValue = excelValue;
		this.result = result;
	}
	

	public String getIterationNum() {
		return iterationNum;
	}

	public void setIterationNum(String iterationNum) {
		this.iterationNum = iterationNum;
	}

	public String getXmlValue() {
		return xmlValue;
	}

	public void setXmlValue(String xmlValue) {
		this.xmlValue = xmlValue;
	}

	public String getExcelValue() {
		return excelValue;
	}

	public void setExcelValue(String excelValue) {
		this.excelValue = excelValue;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	

}
