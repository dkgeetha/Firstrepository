package HTML_Report;
import java.util.HashMap;
import java.util.Map;
import HTML_Report.Status;

public class Report  {
	
int it = 1;
int compit = 1;
private Map<Integer, CustomReport> results = new HashMap<Integer, CustomReport>(); 
private Map<Integer, ComparingResult> compResult = new HashMap<Integer, ComparingResult>();


/**
 * 
 * @param Sprint
 * @param TestcaseID
 * @param testCaseDesc
 * @param result
 * @param failReason
 * @param imageForFail
 */
	public void UpdateResult(String Sprint ,String TestcaseID, String testCaseDesc,Status result , String failReason, String imageForFail)
	{
		
		CustomReport testResult = new CustomReport(Sprint, TestcaseID, testCaseDesc , result, failReason,imageForFail );
		
		results.put(it, testResult);
		it++;
 
		
	}
	
	/**
	 * 
	 */
	public void Generate_Report()
	{
		Report_Generator rep = new Report_Generator();
		
		rep.Initialize_Summary(results);
		
	}
	
	
	
	
	/**
	 * 
	 * @param iterationNum
	 * @param fieldName
	 * @param xmlValue
	 * @param excelValue
	 * @param result
	 */
	public void updateCompareResult(String iterationNum, String fieldName, String xmlValue, String excelValue, String result)
	{
		ComparingResult compresult = new ComparingResult(fieldName, iterationNum, xmlValue, excelValue, result);
		compResult.put(compit, compresult);
		compit= compit+1;
		
	}

}
