package HTML_Report;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;

import Utilities.Utility;


/**
 * Class to encapsulate the HTML report generation functions of the framework
 * @author 
 */
public class HtmlReport 
{
	private String testLogPath, resultSummaryPath;
	private ReportSettings reportSettings;
	private ReportTheme reportTheme;
	
	private boolean isTestLogHeaderTableCreated = false;
	private boolean isTestLogMainTableCreated = false;
	private boolean isResultSummaryHeaderTableCreated = false;
	private boolean isResultSummaryMainTableCreated = false;
	
	private String currentSection = "";
	private String currentSubSection = "";
	private int currentContentNumber = 1;
	
	

	private int setpnumber = 1;
	
	
	Utility Util = new Utility();
	/**
	 * Constructor to initialize the HTML report
	 * @param reportSettings The {@link ReportSettings} object
	 * @param reportTheme The {@link ReportTheme} object
	 */
	public HtmlReport(ReportSettings reportSettings, ReportTheme reportTheme)
	{
		this.reportSettings = reportSettings;
		this.reportTheme = reportTheme;
			
		testLogPath = reportSettings.ReportPath + Util.getFileSeparator() +
				"XML Results" + Util.getFileSeparator() + reportSettings.timeStamp+"_Comparision" + ".html";
		
		resultSummaryPath = reportSettings.ReportPath + Util.getFileSeparator() +
								"HTML Results" + Util.getFileSeparator() + reportSettings.timeStamp+"_Summary" + ".html";
	}
	
	
	private String getThemeCss() {
        String themeCss = "\t\t <style type='text/css'> \n"
                     + "\t\t\t body { \n" + "\t\t\t\t background-color: "
                     + reportTheme.getContentForeColor()
                     + "; \n"
                     +
                     // "\t\t\t\t font-family: Verdana, Geneva, sans-serif; \n" +
                     "\t\t\t\t font-family: Copperplate Gothic Bold; \n"
                     + "\t\t\t\t font-size: 1.0em; \n"
                     + "\t\t\t\t text-align: center; \n"
                     + "\t\t\t } \n\n"
                     +

                     "\t\t\t small { \n"
                     + "\t\t\t\t font-size: 0.7em; \n"
                     + "\t\t\t } \n\n"
                     +

                     "\t\t\t table { \n"
                     +
                     // "\t\t\t\t border: 1px solid black; \n" +
                     // "\t\t\t\t border: 1px solid #000000; \n" +
                     // "\t\t\t\t border-collapse: collapse; \n" +
                     // "\t\t\t\t border-collapse: Separated; \n" +
                     // "\t\t\t\t border-spacing: 1px; \n" +
                     "\t\t\t\t width: 1200px; \n"
                     + "\t\t\t\t margin-left: auto; \n"
                     + "\t\t\t\t margin-right: auto; \n"
                     + "\t\t\t } \n\n"
                   +

                     "\t\t\t td, th { \n"
                     + "\t\t\t\t border: 1px solid white; \n"
                     + "\t\t\t\t border-collapse: separated; \n"
                     + "\t\t\t\t border-spacing: 1px; \n"
                     +
                     // "\t\t\t\t padding: 4px; \n" +
                     "\t\t\t\t text-align: inherit\\0/; \n"
                     + "\t\t\t } \n\n"
                     +

                     "\t\t\t tr.heading { \n"
                     +
                     // "\t\t\t\t border: 2px solid #000000; \n" +
                     // "\t\t\t\t border-collapse: separated; \n" +
                     "\t\t\t background-color: "
                     + reportTheme.getHeadingBackColor()
                     + "; \n"
                     + "\t\t\t\t color: "
                     + reportTheme.getHeadingForeColor()
                     + "; \n"
                     + "\t\t\t\t font-size: 0.9em; \n"
                     + "\t\t\t\t font-weight: bold; \n"
                     + "\t\t\t } \n\n"
                     +

                     "\t\t\t tr.subheading { \n"
                     +
                     // "\t\t\t\t border: 2px solid #000000; \n" +
                     // "\t\t\t\t border-collapse: separated; \n" +
                     "\t\t\t\t background-color: "
                     + reportTheme.getHeadingForeColor()
                     + "; \n"
                     + "\t\t\t\t color: "
                     + reportTheme.getHeadingBackColor()
                     + "; \n"
                     + "\t\t\t\t font-weight: bold; \n"
                     + "\t\t\t\t font-size: 0.9em; \n"
                     + "\t\t\t\t text-align: justify; \n"
                     +
                     // "\t\t\t\t text-align: justify; \n" +
                     "\t\t\t } \n\n"
                     +

                     "\t\t\t tr.section { \n"
                     +
                     // "\t\t\t\t border: 2px solid #000000; \n" +
                     // "\t\t\t\t border-collapse: separated; \n" +
                     "\t\t\t\t background-color: "
                     + reportTheme.getSectionBackColor()
                     + "; \n"
                     + "\t\t\t\t color: "
                     + reportTheme.getSectionForeColor()
                     + "; \n"
                     + "\t\t\t\t cursor: pointer; \n"
                     + "\t\t\t\t font-weight: bold; \n"
                     + "\t\t\t\t font-size: 0.9em; \n"
                     + "\t\t\t\t text-align: justify; \n"
                     + "\t\t\t } \n\n"
                     +

                     "\t\t\t tr.subsection { \n"
                     + "\t\t\t\t cursor: pointer; \n"
                     + "\t\t\t } \n\n"
                     +

                     "\t\t\t tr.content { \n"
                     +
                     // "\t\t\t\t border: 2px solid #000000; \n" +
                     // "\t\t\t\t border-collapse: separated; \n" +
                     "\t\t\t\t background-color: "
                     + reportTheme.getContentBackColor()
                     + "; \n"
                     + "\t\t\t\t color: "
                     + reportTheme.getContentForeColor()
                     + "; \n"
                     + "\t\t\t\t font-size: 0.9em; \n"
                     + "\t\t\t\t display: table-row; \n"
                     + "\t\t\t } \n\n"
                     +

                     "\t\t\t td.justified { \n"
                     + "\t\t\t\t text-align: justify; \n"
                     + "\t\t\t } \n\n"
                     +"\t\t\t td.left { \n" +
						"\t\t\t\t text-align: left; \n" +
					"\t\t\t } \n\n" +

                     // "\t\t\t a.justified:link { \n" +
                     // "\t\t\t\t text-align: justify; \n" +
                     // "\t\t\t } \n\n" +

                     "\t\t\t td.pass { \n"
                     + "\t\t\t\t font-weight: bold; \n"
                     + "\t\t\t\t color: green; \n"
                     + "\t\t\t } \n\n"
                     +

                     "\t\t\t td.fail { \n"
                     + "\t\t\t\t font-weight: bold; \n"
                     + "\t\t\t\t color: red; \n"
                     + "\t\t\t } \n\n"
                     +"\t\t\t td.equal { \n" +
						"\t\t\t\t font-weight: bold; \n" +
						"\t\t\t\t color: green; \n" +
					"\t\t\t } \n\n" +
					
					"\t\t\t td.different { \n" +
						"\t\t\t\t font-weight: bold; \n" +
						"\t\t\t\t color: red; \n" +
					"\t\t\t } \n\n" +

                     // "\t\t\t a:link { \n" +
                     // "\t\t\t\t font-weight: bold; \n" +
                     // "\t\t\t\t color: red; \n" +
                     // "\t\t\t } \n\n" +

                     // "\t\t\t a.fail:link { \n" +
                     // "\t\t\t\t font-weight: bold; \n" +
                     // "\t\t\t\t color: red; \n" +
                     // "\t\t\t } \n\n" +
                     //
                     // "\t\t\t a.fail:active { \n" +
                     // "\t\t\t\t font-weight: bold; \n" +
                     // "\t\t\t\t color: red; \n" +
                     // "\t\t\t } \n\n" +

                     "\t\t\t td.done,td.screenshot { \n"
                     + "\t\t\t\t font-weight: bold; \n"
                     + "\t\t\t\t color: black; \n"
                     + "\t\t\t } \n\n"
                     +

                     // "\t\t\t td.screenshot { \n" +
                     // "\t\t\t\t font-weight: bold; \n" +
                     // "\t\t\t\t color: red; \n" +
                     // "\t\t\t } \n\n" +

                     "\t\t\t td.debug { \n"
                     + "\t\t\t\t font-weight: bold; \n"
                     + "\t\t\t\t color: blue; \n"
                     + "\t\t\t } \n\n"
                     +

                     "\t\t\t td.warning { \n"
                     + "\t\t\t\t font-weight: bold; \n"
                     + "\t\t\t\t color: orange; \n"
                     + "\t\t\t } \n"
                     + "\t\t </style> \n\n";

        return themeCss;
 }
	private String getJavascriptFunctions()
	{
		String javascriptFunctions =	"\t\t <script> \n" +
											"\t\t\t function toggleMenu(objID) { \n" +
												"\t\t\t\t if (!document.getElementById) return; \n" +
												"\t\t\t\t var ob = document.getElementById(objID).style; \n" +
												"\t\t\t\t if(ob.display === 'none') { \n" +
													"\t\t\t\t\t try { \n" +
														"\t\t\t\t\t\t ob.display='table-row-group'; \n" +
													"\t\t\t\t\t } catch(ex) { \n" +
														"\t\t\t\t\t\t ob.display='block'; \n" +
													"\t\t\t\t\t } \n" +
												"\t\t\t\t } \n" +
												"\t\t\t\t else { \n" +
													"\t\t\t\t\t ob.display='none'; \n" +
												"\t\t\t\t } \n" +
											"\t\t\t } \n" +
											
											"\t\t\t function toggleSubMenu(objId) { \n" +
												"\t\t\t\t for(i=1; i<10000; i++) { \n" +
													"\t\t\t\t\t var ob = document.getElementById(objId.concat(i)); \n" +
													"\t\t\t\t\t if(ob === null) { \n" +
														"\t\t\t\t\t\t break; \n" +
													"\t\t\t\t\t } \n" +
													"\t\t\t\t\t if(ob.style.display === 'none') { \n" +
														"\t\t\t\t\t\t try { \n" +
															"\t\t\t\t\t\t\t ob.style.display='table-row'; \n" +
														"\t\t\t\t\t\t } catch(ex) { \n" +
															"\t\t\t\t\t\t\t ob.style.display='block'; \n" +
														"\t\t\t\t\t\t } \n" +
													"\t\t\t\t\t } \n" +
													"\t\t\t\t\t else { \n" +
														"\t\t\t\t\t\t ob.style.display='none'; \n" +
													"\t\t\t\t\t } \n" +
												"\t\t\t\t } \n" +
											"\t\t\t } \n" +
										 "\t\t </script> \n";
		
		return javascriptFunctions;
	}
	
	
	/* TEST LOG FUNCTIONS*/
	
	
	public void initializeTestLog()
	{
		File testLogFile = new File(testLogPath);
		try {
			testLogFile.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Error while creating HTML test log file");
		}
		
		FileOutputStream outputStream = null;
		try {
			outputStream = new FileOutputStream(testLogFile);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.out.println("Cannot find HTML test log file");
		}
		PrintStream printStream = new PrintStream(outputStream);
		
		String testLogHeadSection;
		testLogHeadSection = 	"<!DOCTYPE html> \n" +
								"<html> \n" +
								"\t <head> \n" +
									"\t\t <meta charset='UTF-8'> \n" +
									"\t\t <title>" +
									ReportSettings.ProjectName +
										" - " +	reportSettings.ReportName +
										" XML Comparision Results" +
									"</title> \n\n" +
									getThemeCss() +
									getJavascriptFunctions() +
								"\t </head> \n";
		
        printStream.println(testLogHeadSection);
        printStream.close();
	}
	
	
	public void addTestLogHeading(String heading)
	{
		if(!isTestLogHeaderTableCreated) {
			createTestLogHeaderTable();
			isTestLogHeaderTableCreated = true;
		}
		
		BufferedWriter bufferedWriter;
		try {
			bufferedWriter = new BufferedWriter(new FileWriter(testLogPath, true));
			
		    String testLogHeading =	"\t\t\t\t <tr class='heading'> \n" +
										"\t\t\t\t\t <th colspan='4' style='font-family:Copperplate Gothic Bold; font-size:1.4em;'> \n" + 
											"\t\t\t\t\t\t " + heading + " \n" +
										"\t\t\t\t\t </th> \n" +
									"\t\t\t\t </tr> \n";
		    bufferedWriter.write(testLogHeading);
		    bufferedWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Error while adding heading to HTML test log");
		}
	}
	
	private void createTestLogHeaderTable()
	{
		BufferedWriter bufferedWriter;
		try {
			bufferedWriter = new BufferedWriter(new FileWriter(testLogPath, true));
			
		    String testLogHeaderTable =	"\t <body> \n" +
											"\t\t <table id='header'>"
											+ " <col width = '900'>"
											+ "<col width = 'auto'>"
											+ "<col width = 'auto'>"
											
											+ "\n" +
												"\t\t\t <thead> \n";
		    bufferedWriter.write(testLogHeaderTable);
		    bufferedWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Error while adding header table to HTML test log");
		}
	}
	
	
	public void addTestLogSubHeading(String subHeading1, String subHeading2,
										String subHeading3, String subHeading4)
	{
		BufferedWriter bufferedWriter;
		try {
			bufferedWriter = new BufferedWriter(new FileWriter(testLogPath, true));
			
		    String testLogSubHeading =	"\t\t\t\t <tr class='subheading'> \n" +
											"\t\t <th>&nbsp;" + subHeading1.replace(" ", "&nbsp;") + "</th> \n" +
											/*"\t\t\t\t\t <th>&nbsp;" + subHeading2.replace(" ", "&nbsp;") + "</th> \n" +*/
											"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<th>&nbsp;" + subHeading3.replace(" ", "&nbsp;") + "</th>\n \n" +
											"\t\t <th>&nbsp;" + subHeading4.replace(" ", "&nbsp;") + "</th> \n" +
										"\t\t\t\t </tr> \n";
		    bufferedWriter.write(testLogSubHeading);
		    bufferedWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Error while adding sub-heading to HTML test log");
		}
	}
	
	private void createTestLogMainTable()
	{
		BufferedWriter bufferedWriter;
		try {
			bufferedWriter = new BufferedWriter(new FileWriter(testLogPath, true));
			
		    String testLogMainTable =		"\t\t\t </thead> \n" +
										 "\t\t </table> \n\n" +
										 
										 "\t\t <table id='main'>"
										 + " <col width='100'> "
										 + "<col width='150'>"
										 + "<col width='300'>"+
										 "<col width='250'>"
										 + "<col width='250'>"
										 + "<col width='auto'>"
										 + "\n";
			
		    bufferedWriter.write(testLogMainTable);
		    bufferedWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Error while adding main table to HTML test log");
		}
	}
	
	
	public void addTestLogTableHeadings()
	{
		if(!isTestLogMainTableCreated) {
			createTestLogMainTable();
			isTestLogMainTableCreated = true;
		}
		
		BufferedWriter bufferedWriter;
		try {
			bufferedWriter = new BufferedWriter(new FileWriter(testLogPath, true));
			
		    String testLogTableHeading =	"\t\t\t<thead> \n" +
												"\t\t\t\t\t <tr class='heading'> \n" +
													"\t\t\t\t\t <th>Seral No</th> \n" +
													"\t\t\t\t\t <th>Iteration Number</th> \n"+
													"\t\t\t\t\t<th>Field Name/Description</th> \n" +
													"\t\t\t\t \t<th>XML Value</th> \n" +
													/*"\t\t\t\t\t <th>\t</th> \n" +*/
													"\t\t\t\t\t <th>Excel Value</th> \n" +
													"\t\t\t\t\t <th>Result</th> \n" +
													
												"\t\t\t\t </tr> \n" +
											"\t\t\t </thead> \n\n";
		    bufferedWriter.write(testLogTableHeading);
		    bufferedWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Error while adding main table headings to HTML test log");
		}
	}
	
	
	public void addTestLogSection(String section)
	{
		String testLogSection = "";
		if (!currentSection.equals("")) {
			testLogSection = "\t\t\t </tbody>";
		}
		
		currentSection = section.replaceAll("[^a-zA-Z0-9]", "");
		
		BufferedWriter bufferedWriter;
		try {
			bufferedWriter = new BufferedWriter(new FileWriter(testLogPath, true));
			
		    testLogSection +=	"\t\t\t <tbody> \n" +
										"\t\t\t\t <tr class='section'> \n" +
											"\t\t\t\t\t <td colspan='8' onclick=\"toggleMenu('" + currentSection + "')\">+ " +
												section + "</td> \n" +
										"\t\t\t\t\t\t\t </tr> \n" + "\t\t\t\t </tr> \n"+ "\t\t\t\t </tr> \n"+
									"\t\t\t </tbody> \n" +
									"\t\t\t <tbody id='" + currentSection + "' style='display:table-row-group'> \n";
		    bufferedWriter.write(testLogSection);
		    bufferedWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Error while adding section to HTML test log");
		}
	}
	
	
	public void addTestLogSubSection(String subSection)
	{
		currentSubSection = subSection.replaceAll("[^a-zA-Z0-9]", "");
		currentContentNumber = 1;
		
		BufferedWriter bufferedWriter;
		try {
			bufferedWriter = new BufferedWriter(new FileWriter(testLogPath, true));
			
		    String testLogSubSection =	"\t\t\t\t <tr class='subheading subsection'> \n" +
											"\t\t\t\t\t <td colspan='8' onclick=\"toggleSubMenu('" + currentSection + currentSubSection + "')\">&nbsp;+ " +
												subSection + "</td> \n" +
										"\t\t\t\t </tr> \n";
		    bufferedWriter.write(testLogSubSection);
		    bufferedWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Error while adding sub-section to HTML test log");
		}
	}
	
	
	public void updateTestLog(String iterationNum,String fieldName, String col4, String stepDescription, Status stepStatus)
	{
		try {
			BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(testLogPath, true));
			
			String testStepRow = "\t\t\t\t <tr class='content' id='" + currentSection + currentSubSection + currentContentNumber + "'> \n" +
					"\t\t\t\t\t\t\t\t <td>" + setpnumber + "</td> \n" +				
					"\t\t\t\t\t\t\t\t <td>" + iterationNum + "</td> \n" +
									"\t\t\t\t\t\t\t <td class='left'>" + fieldName + "</td> "+
									"\t\t\t\t\t\t\t <td class='left'>" + col4 + "</td> ";
			currentContentNumber++;//setpnumber
			setpnumber++;
		 	testStepRow +=	 
						
					"</td> " ;
					/*"<td>\t\t\t\t\t\t\t\t " +"</td> " + //"\t\t\t\t\t <td>" 
	"\t\t\t\t ";*/
			
			switch (stepStatus) {
			
			case FAIL:

					testStepRow += getTestStepWithoutScreenshot(stepDescription, stepStatus);
				
				break;
			
			case PASS:
				
					testStepRow += getTestStepWithoutScreenshot(stepDescription, stepStatus);
				
				break;
				
			case SCREENSHOT:
				//testStepRow += getTestStepWithScreenshot(stepDescription, stepStatus, screenShotName);
				break;
				
			default:
				testStepRow += getTestStepWithoutScreenshot(stepDescription, stepStatus);
				break;
			}
			
			testStepRow +="</tr> \n";
	       	
		    bufferedWriter.write(testStepRow);
		    bufferedWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Error while updating HTML test log");
		}
	}
	
	/*private String getTestStepWithScreenshot(String stepDescription, Status stepStatus, String screenShotName)
	{
		String testStepRow;
		
		if (reportSettings.linkScreenshotsToTestLog) {
			testStepRow = 
					"\t\t\t\t\t <td class='justified'>" +
									stepDescription +
								"</td> \n" +
					"\t\t\t\t\t <td class='" + stepStatus.toString().toLowerCase() + "'>" +
							 		"<a href='..\\Screenshots\\" + screenShotName + "'>" +
				 						stepStatus +
				 					"</a>" +
				 				"</td> \n";
		} else {
			testStepRow = 
					"\t\t\t\t\t <td class='justified'>" +
									stepDescription + " (Refer Screenshot @ " + screenShotName + ")" +
								"</td> \n" +
					"\t\t\t\t\t <td class='" + stepStatus.toString().toLowerCase() + "'>" +
				 					stepStatus +
				 				"</td> \n";
		}
		
		return testStepRow;
	}
	*/
	private String getTestStepWithoutScreenshot(String stepDescription, Status stepStatus)
	{
		String testStepRow;
		
		testStepRow = 
				"\t\t\t\t <td class='left'>" +
								stepDescription +
							"</td> \n" +
				"\t\t\t\t\t\t <td class='" + stepStatus.toString().toLowerCase() + "'>" +
			 					stepStatus +
			 				"</td> \n";
		
		return testStepRow;
	}
	
	
	public void addTestLogFooter(int  totalfields, int nStepsPassed, int nStepsFailed)
	{
		try {
			BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(testLogPath, true));
		    
			String testLogFooter =	"\t\t\t </tbody> \n" +
								"\t\t </table> \n\n" +
								
								"\t\t <table id='footer'> \n" +
									"\t\t\t <colgroup> \n" +
										"\t\t\t\t <col style='width: 25%' /> \n" +
										"\t\t\t\t <col style='width: 25%' /> \n" +
										"\t\t\t\t <col style='width: 25%' /> \n" +
										"\t\t\t\t <col style='width: 25%' /> \n" +
									"\t\t\t </colgroup> \n\n" +
									
									"\t\t\t <tfoot> \n" +
										"\t\t\t\t <tr class='heading'> \n" + 
											"\t\t\t\t\t <th colspan='4'>Total Number of Fields Tested : " + totalfields + "</th> \n" + 
										"\t\t\t\t </tr> \n" +
										"\t\t\t\t <tr class='subheading'> \n" + 
											"\t\t\t\t\t <td class='pass'>&nbsp;Steps passed</td> \n" + 
											"\t\t\t\t\t <td class='pass'>&nbsp;: " + nStepsPassed + "</td> \n" +
											"\t\t\t\t\t <td class='fail'>&nbsp;Steps failed</td> \n" + 
											"\t\t\t\t\t <td class='fail'>&nbsp;: " + nStepsFailed + "</td> \n" +
										"\t\t\t\t </tr> \n" +
									"\t\t\t </tfoot> \n" +
								"\t\t </table> \n" +
							"\t </body> \n" +
						"</html>";
		    
		    bufferedWriter.write(testLogFooter);
		    bufferedWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Error while adding footer to HTML test log");
		}
	}
	
	
	/* RESULT SUMMARY FUNCTIONS*/
	
	
	public void initializeResultSummary()
	{
		File resultSummaryFile = new File(resultSummaryPath);
		
		try {
			resultSummaryFile.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Error while creating HTML result summary file");
		}
		
		FileOutputStream outputStream = null;
		try {
			outputStream = new FileOutputStream(resultSummaryFile);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.out.println("Cannot find HTML result summary file");
		}
		PrintStream printStream = new PrintStream(outputStream);
		
		String resultSummaryHeader;
		resultSummaryHeader = 	"<!DOCTYPE html> \n" +
								"<html> \n" +
								"\t <head> \n" +
									"\t\t <meta charset='UTF-8'> \n" +
									"\t\t <title>" +
									ReportSettings.ProjectName +
										" - Automation Execution Results Summary" +
									"</title> \n\n" +
									getThemeCss() +
									getJavascriptFunctions() +
								"\t </head> \n";
		
		printStream.println (resultSummaryHeader);
        printStream.close();
	}
	
	
	public void addResultSummaryHeading(String heading)
	{
		if(!isResultSummaryHeaderTableCreated) {
			createResultSummaryHeaderTable();
			isResultSummaryHeaderTableCreated = true;
		}
		
		BufferedWriter bufferedWriter;
		try {
			bufferedWriter = new BufferedWriter(new FileWriter(resultSummaryPath, true));
			
		    String resultSummaryHeading =	"\t\t\t\t <tr class='heading'> \n" +
												"\t\t\t\t\t <th colspan='4' style='font-family:Copperplate Gothic Bold; font-size:1.4em;'> \n" + 
													"\t\t\t\t\t\t " + heading + " \n" +
												"\t\t\t\t\t </th> \n" +
											"\t\t\t\t </tr> \n";
		    bufferedWriter.write(resultSummaryHeading);
		    bufferedWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Error while adding heading to HTML result summary");
		}
	}
	
	public void createResultSummaryHeaderTable()
	{
		BufferedWriter bufferedWriter;
		try {
			bufferedWriter = new BufferedWriter(new FileWriter(resultSummaryPath, true));
			
		    String resultSummaryHeaderTable =	"\t <body> \n" +
													"\t\t <table id='header'> \n" +
														"\t\t\t <thead> \n";
		    bufferedWriter.write(resultSummaryHeaderTable);
		    bufferedWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Error while adding header table to HTML result summary");
		}
	}
	
	 
	public void addResultSummarySubHeading(String subHeading1, String subHeading2,
											String subHeading3, String subHeading4)
	{
		BufferedWriter bufferedWriter;
		try {
			bufferedWriter = new BufferedWriter(new FileWriter(resultSummaryPath, true));
			
		    String resultSummarySubHeading =	"\t\t\t\t <tr class='subheading'> \n" +
													"\t\t\t\t\t <th>&nbsp;" + subHeading1.replace(" ", "&nbsp;") + "</th> \n" +
													"\t <th>&nbsp;" + subHeading2.replace(" ", "&nbsp;") + "</th> \n" +
													"\t\t\t\t\t <th>&nbsp;" + subHeading3.replace(" ", "&nbsp;") + "</th> \n" +
													"\t\t\t\t\t <th>&nbsp;" + subHeading4.replace(" ", "&nbsp;") + "</th> \n" +
												"\t\t\t\t </tr> \n";
		    bufferedWriter.write(resultSummarySubHeading);
		    bufferedWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Error while adding sub-heading to HTML result summary");
		}
	}
	
	public void createResultSummaryMainTable()
	{
		BufferedWriter bufferedWriter;
		try {
			bufferedWriter = new BufferedWriter(new FileWriter(resultSummaryPath, true));
			
		    String resultSummaryMainTable =	"\t\t </thead> \n" +//deleted one \t
										 "\t </table> \n\n" + //deleted one \t
										 
										 "\t\t <table id='main'> \n" + 
											"\t\t\t <colgroup> \n";
		    
		    bufferedWriter.write(resultSummaryMainTable);
		    bufferedWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Error while adding main table to HTML result summary");
		}
	}
	
	 
	public void addResultSummaryTableHeadings()
	{
		if(!isResultSummaryMainTableCreated) {
			createResultSummaryMainTable();
			isResultSummaryMainTableCreated = true;
		}
		
		BufferedWriter bufferedWriter;
		try {
			bufferedWriter = new BufferedWriter(new FileWriter(resultSummaryPath, true));
			
		    String resultSummaryTableHeading =	"\t\t\t <thead> \n" +
												"\t\t\t\t <tr class='heading'> \n" + 
													" <th>Test CaseID</th> \n" +
													"\t\t\t <th>Test CaseName</th> \n" +
													"\t\t\t\t\t <th>Test Description</th> \n" +
													"\t\t\t\t\t <th>Fail Reason</th> \n" +
													"\t\t\t\t\t <th> Reference</th> \n" +
													"\t\t\t\t\t <th> Test Status</th> \n" +
												"\t\t\t\t </tr> \n" +
											"\t\t\t </thead> \n\n";
		    bufferedWriter.write(resultSummaryTableHeading);
		    bufferedWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Error while adding main table headings to HTML result summary");
		}
	}
	
	 
	public void updateResultSummary(String scenario_sprint, String testcaseName, String testcaseDescription, String failreason, String screenShotName, String testStatus )
	{
		try {
			BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(resultSummaryPath, true));
		    
			String testcaseRow;
			
			if (reportSettings.linkTestLogsToSummary) {
				testcaseRow = 	"\t\t\t\t\t\t\t\t\t <tr class='content' > \n" +
									"\t\t\t\t\t\t\t\t\t\t\t\t <td class='justified'>" + scenario_sprint + "</td> \n" +
									"\t\t\t\t\t <td class='justified'><a href='" + scenario_sprint + "_" + testcaseName + ".html' " +
														"target='about_blank'>" + testcaseName + "</a>" +
												"</td> \n" +
									"\t\t\t\t\t <td class='justified'>" + testcaseDescription + "</td> \n" +
									"\t\t\t\t\t <td>" + failreason + "</td> \n";
			} else {
				
				if(testStatus.equalsIgnoreCase("pass"))
				{
					testcaseRow = 	"\t\t\t\t\t\t\t\t\t\t<tr class='content' > \n" +
							"\t\t\t\t\t\t\t\t\t\t <td class='justified'>" + scenario_sprint + "</td> \n" +
							"\t\t\t\t\t\t\t\t <td class='justified'>" + testcaseName + "</td> \n" +
							"\t\t\t\t\t\t\t\t\t\t <td class='justified'>" + testcaseDescription + "</td> \n" +
							"\t\t\t\t\t\t\t <td>" + failreason + "</td> \n"+
							"\t\t\t\t\t <td class='justified'>" +
							"<a href='..\\..\\..\\Screenshots\\" + screenShotName +".png"+ "'>" +" "+"</a>"+
	 											"</td> \n";
					
				}else{
					testcaseRow = 	"\t\t\t\t\t\t\t\t\t\t<tr class='content' > \n" +
							"\t\t\t\t\t\t\t\t\t\t <td class='justified'>" + scenario_sprint + "</td> \n" +
							"\t\t\t\t\t\t\t\t <td class='justified'>" + testcaseName + "</td> \n" +
							"\t\t\t\t\t\t\t\t\t\t <td class='justified'>" + testcaseDescription + "</td> \n" +
							"\t\t\t\t\t\t\t <td>" + failreason + "</td> \n"+ 
							"\t\t\t\t\t <td class='justified'>" +
							"<a href='..\\..\\..\\Screenshots\\" + screenShotName +".png"+ "'>" +"Screenshot"+"</a>"+
	 											"</td> \n"; 
					
				}
				
			
				
			/*	testcaseRow = 	"\t\t\t\t <tr class='content' > \n" +
						"\t\t\t\t\t <td class='justified'>" + tc_ID + "</td> \n" +
						"\t\t\t\t\t <td class='justified'>" + testcaseName + "</td> \n" +
						"\t\t\t\t\t <td class='justified'>" + testcaseDescription + "</td> \n" +
						"\t\t\t\t\t <td>" + failreason + "</td> \n"+ 
						"\t\t\t\t\t <td class='justified'>" + "Screenshot" +"'>"+
						"<a href='..\\..\\..\\Screenshots\\" + screenShotName +".png"+ "'/>" +
 											"</td> \n"; //"</a>" +*/	
				}
		    
			if(testStatus.equalsIgnoreCase("pass")) {
				testcaseRow += 		"\t\t\t\t\t <td class='pass'>" + testStatus + "</td> \n" +
								"\t\t\t\t </tr> \n";
			}
			else {
				testcaseRow += 		"\t\t\t\t\t <td class='fail'>" + testStatus + "</td> \n" +
								"\t\t\t\t </tr> \n";
			}
			
		    bufferedWriter.write(testcaseRow);
		   	bufferedWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Error while updating HTML result summary");
		}
	}
	
	 
	public void addResultSummaryFooter(String totalExecutionTime,
										int nTestsPassed, int nTestsFailed)
	{
		try {
			BufferedWriter bufferWriter = new BufferedWriter(new FileWriter(resultSummaryPath, true));
			
		    String resultSummaryFooter =	"\t\t\t </tbody> \n" +
										"\t\t </table> \n\n" +
										
										"\t\t <table id='footer'> \n" +
											"\t\t\t <colgroup> \n" +
												"\t\t\t\t <col style='width: 25%' /> \n" +
												"\t\t\t\t <col style='width: 25%' /> \n" +
												"\t\t\t\t <col style='width: 25%' /> \n" +
												"\t\t\t\t <col style='width: 25%' /> \n" +
											"\t\t\t </colgroup> \n\n" +
											
											"\t\t\t <tfoot> \n" +
												"\t\t\t\t <tr class='heading'> \n" + 
													"\t\t\t\t\t <th colspan='4'>"
													+ "Number of Testcases Run: " + totalExecutionTime + 
													"</th> \n" + 
												"\t\t\t\t </tr> \n" +
												"\t\t\t\t <tr class='subheading'> \n" + 
													"\t\t\t\t\t <td class='pass'>&nbsp;Tests passed</td> \n" + 
													"\t\t\t\t\t <td class='pass'>&nbsp;: " + nTestsPassed + "</td> \n" +
													"\t\t\t\t\t <td class='fail'>&nbsp;Tests failed</td> \n" + 
													"\t\t\t\t\t <td class='fail'>&nbsp;: " + nTestsFailed + "</td> \n" +
												"\t\t\t\t </tr> \n" +
											"\t\t\t </tfoot> \n" +
										"\t\t </table> \n" +
									"\t </body> \n" +
								"</html>";
		    
		    bufferWriter.write(resultSummaryFooter);
			bufferWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Error while adding footer to HTML result summary");
		}
	}
	
	/**
	 * Function to open the generated Summary report
	 */
	public void openReport()
	{
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		if (true) {
			try {
				Runtime.getRuntime().exec("RunDLL32.EXE shell32.dll,ShellExec_RunDLL " +
						reportSettings.ReportPath + Util.getFileSeparator() +
						"HTML Results" + Util.getFileSeparator() + reportSettings.timeStamp+"_Summary" + ".html");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
/**
 * Function to open generated COmparison result
 */
	public void openComparisionReport()
	{
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		if (true) {
			try {
				Runtime.getRuntime().exec("RunDLL32.EXE shell32.dll,ShellExec_RunDLL " +
						reportSettings.ReportPath + Util.getFileSeparator() +
						"XML Results" + Util.getFileSeparator() + reportSettings.timeStamp+"_Comparision" + ".html");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
}