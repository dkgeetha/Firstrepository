/*package executionEngine;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class DriverScript {

	public static void main(String[] args) {
		
		WebDriver driver=null;
	System.setProperty("webdriver.ie.driver", "C:\\workspace\\Libraries\\bin\\IEDriverServer.exe");
		//System.setProperty("webdriver.gecko.driver", "H:\\AIG\\Softwares\\geckodriver.exe");
		
		 driver = new InternetExplorerDriver();
		// driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//driver=new FirefoxDriver();
	//	// driver.get("http://www.store.demoqa.com");
		 driver.get("https://qadmp.aigcorporate.com/_20_159205.html");
		 

driver.findElement(By.xpath(".//*[@id='loginFlds']/span[2]/input")).sendKeys("testuser_3"); 
driver.findElement(By.xpath(".//*[@id='loginFlds']/span[4]/input")).sendKeys("Test@123");
driver.findElement(By.xpath(".//*[@id='loginSubmit']/span/input")).click();


		 driver.quit();
	
		
		
	}

}*/



//============





 package executionEngine;
 
import Config.Actionkeyword;
import Utility.ExcelUtils;
 
public class DriverScript {
 
    public static void main(String[] args) throws Exception {
    	// Declaring the path of the Excel file with the name of the Excel file
    	String sPath = "C:\\Workout\\DataEngine.xlsx";
 
    	// Here we are passing the Excel path and SheetName as arguments to connect with Excel file 
    	ExcelUtils.setExcelFile(sPath, "Test Steps");
 
    	//Hard coded values are used for Excel row & columns for now
    	//In later chapters we will replace these hard coded values with varibales
    	//This is the loop for reading the values of the column 3 (Action Keyword) row by row
    	for (int iRow=1;iRow<=9;iRow++){
		    //Storing the value of excel cell in sActionKeyword string variable
    		String sActionKeyword = ExcelUtils.getCellData(iRow, 3);
 
    		//Comparing the value of Excel cell with all the project keywords
    		if(sActionKeyword.equals("openBrowser")){
                        //This will execute if the excel cell value is 'openBrowser'
    			//Action Keyword is called here to perform action
    			Actionkeyword.openBrowser();
    			}
    		else if(sActionKeyword.equals("navigate")){
    			Actionkeyword.navigate();}
    		
    		

    		else if(sActionKeyword.equals("input_Username")){
    			Actionkeyword.input_Username();}
    		else if(sActionKeyword.equals("input_Password")){
    			Actionkeyword.input_Password();}
    		else if(sActionKeyword.equals("click_Login")){
    			Actionkeyword.click_Login();}
    		else if(sActionKeyword.equals("waitFor")){
    			Actionkeyword.waitFor();}
    	
    		else if(sActionKeyword.equals("closeBrowser")){
    			Actionkeyword.closeBrowser();}
 
    		}
    	}
 }

 