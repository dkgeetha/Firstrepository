package Config;
 
import java.util.concurrent.TimeUnit;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
 
public class Actionkeyword {
 
		public static WebDriver driver;
 
	public static void openBrowser(){		
		System.setProperty("webdriver.ie.driver", "C:\\workspace\\Libraries\\bin\\IEDriverServer.exe");
		driver = new InternetExplorerDriver();
		driver.manage().window().maximize();
		}
 
	public static void navigate(){	
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://qadmp.aigcorporate.com/_20_159205.html");
		
		}

	
	public static void input_Username(){
		driver.findElement(By.xpath(".//*[@id='loginFlds']/span[2]/input")).sendKeys("testuser_3"); 
		}
 
	public static void input_Password(){
		driver.findElement(By.xpath(".//*[@id='loginFlds']/span[4]/input")).sendKeys("Test@123");
		}
 
	public static void click_Login(){
		driver.findElement(By.xpath(".//*[@id='loginSubmit']/span/input")).click();
		}
 
	public static void waitFor() throws Exception{
		Thread.sleep(5000);
		}
 

 
	public static void closeBrowser(){
			driver.quit();
		}
 
	}

